from django.http import HttpResponse
from django.shortcuts import render
from ..models import OverallProcess,ActivityLog,PersonalNews
import json
import time
import urllib.parse
import pandas as pd
import os
import re
import datetime
from VBService.views import static_path
import shutil
from django.utils import timezone
from django.contrib.auth.decorators import login_required, user_passes_test

to_tz = timezone.get_default_timezone()
# Api 4
#from rest_framework.decorators import api_view

def get_ner_results(request):
    ctx = {}
    session_dict = {}
    content_type = request.headers.get('Content-Type')
    print ('content_type: '+ content_type)
    if content_type == 'application/json':
        print ('request_body: '+ str(request.body))
        session_dict  = json.loads(request.body)
    elif content_type == 'application/x-www-form-urlencoded':
        session_dict['session_id_list'] = request.POST.getlist('session_id_list')
        session_dict['business_type'] = request.POST.getlist('business_type')
    print('session_dict: ' + str(session_dict))
    if 'session_id_list' in session_dict:
        session_id_list = session_dict['session_id_list']
        business_type = session_dict['business_type']
        threshold = -0.3
        current_user = request.user
        log = ActivityLog()
        log.user_name = current_user
        #var = json.loads(request.body)
        log.api_name = 'get_ner_result'
        #log.parameters = str(var)
        log.request_time = timezone.now()
        log.save()

        try:
            with open(static_path.threshold,"r") as f:
                params = json.load(f)
                threshold = params["threshold"]
        except:
            print("wrong")
            pass

        ctx = {}
        ctx['results_list'] = []
        ctx['return_code'] = '0000'
        ctx['return_session_id'] = session_id_list[0]

        for session_id in session_id_list:
            #ops = OverallProcess.objects.filter(session_id=session_id)
            OverallProcess.objects.filter(session_id=session_id).update(user_name = str(current_user))
            ops = OverallProcess.objects.filter(session_id=session_id)
            if len(ops)>0:  # check whether the overall process in this session_id exist
                # TODO 已经交换sme和retail
                op = ops[0]
                ctx['status'] = op.status
                ctx['user'] = op.user_name
                ctx['request_time'] = op.record_created_time.astimezone(to_tz).strftime("%b %d %Y - %H:%M")
                for shareholder in op.shareholders.all():
                    ctx['name'] = shareholder.en_name

                if business_type[0] == "sme" and op.is_shareholders_confirm and op.is_all_ner_finished:
                    info_retrieve_dict = {}
                    info_retrieve_dict['session_id'] = session_id
                    info_retrieve_dict['shareholders_list'] = []
                    for shareholder in op.shareholders.all():
                        person_date = str(shareholder.record_created_time).split(' ')[0]
                        personal_news_links = shareholder.personal_news_links.all()
                        retrieve_ner_dict = {}
                        retrieve_ner_dict['shareholder_ner_list'] = []
                        retrieve_ner_dict['shareholder_ner_list_cn'] = []
                        for news in personal_news_links:
                            if news.news_ner_status and not if_ner_location_empty(news.ner_output_location):
                                ner_result_dict = {}
                                ner_result_dict['person_name'] = news.person_name
                                ner_result_dict['news_id'] = news.id
                                ner_result_dict['news_title'] = news.news_title
                                #ner_result_dict['NegPoint'] = news.NegPoint
                                np = news.NegPoint
                                ner_result_dict['NegPoint'] = float(np)
                                if np <= threshold:
                                    ner_result_dict['checked'] = 1
                                else:
                                    ner_result_dict['checked'] = 0
                                ner_result_dict['ParaText'] = news.ParaText
                                ner_result_dict['Entity'] = news.Entity
                                ner_result_dict['link'] = news.link
                                ner_result_dict['comment'] = bytes(news.comment,"utf-8").decode('unicode_escape')
                                #if 'path=' in news.ner_output_location:
                                   # ner_output_location = news.ner_output_location.split("path=")[0]+'path='+urllib.parse.quote(news.ner_output_location.split("path=")[1])
                                ner_result_dict['ner_output_location'] = news.ner_output_location.split("path=")[0]+'path='+urllib.parse.quote(news.ner_output_location.split("path=")[1])
                                #else:
                                 #   ner_result_dict['ner_output_location'] = '/vbapi/show_data/?path=contents'+ urllib.parse.quote(news.ner_output_location.split('contents')[1])
                                ner_result_dict['crawl_start_time'] = news.crawl_start_time
                                ner_result_dict['crawl_end_time'] = news.crawl_end_time
                                #print (ner_result_dict)
                                if all(ord(c) < 128 for c in ner_result_dict['person_name']):
                                    retrieve_ner_dict['shareholder_ner_list'].append(ner_result_dict)
                                else:
                                    retrieve_ner_dict['shareholder_ner_list_cn'].append(ner_result_dict)
                        info_retrieve_dict['shareholders_list'].append(retrieve_ner_dict)
                    ctx['results_list'].append(info_retrieve_dict)
                    #ctx1 = {k: v for k, v in ctx.items() if ctx['user'] == request.user}
                    content_type = request.headers.get('Content-Type')
                    if content_type == 'application/json':
                        return HttpResponse(json.dumps(ctx))
                    elif content_type == 'application/x-www-form-urlencoded':
                        return render(request, 'web/api6.html', ctx)
            elif len(ops) <= 0:
                ctx["return_code"] = "No such session id"
                ctx['status'] = 'No such session id'
                content_type = request.headers.get('Content-Type')
                if content_type == 'application/json':
                    return HttpResponse(json.dumps(ctx))
                elif content_type == 'application/x-www-form-urlencoded':
                    return render(request, 'web/api6.html', ctx)
                #return render(request, 'web/api6.html', ctx)
        content_type = request.headers.get('Content-Type')
        if content_type == 'application/json':
            return HttpResponse(json.dumps(ctx))
        elif content_type == 'application/x-www-form-urlencoded':
            return render(request, 'web/api6.html', ctx)
        #return render(request, 'web/api6.html', ctx)
    else:
        ctx['status'] = 'Input Error: Missing key session_id_list'
        return HttpResponse('Bad Request')

def save_comments(request):
    session_dict  = json.loads(request.body)
    session_id = session_dict["session_id"]
    comments = session_dict["comments"]

    news_ids = list(comments.keys())
    all_news = PersonalNews.objects.filter(id__in=news_ids)
    for news in all_news:
        comment = comments[str(news.id)]
        # mysql has difficuty save chinese character, this this a workaround
        # to get the string version of comment, do:  bytes(comment,"utf-8").decode('unicode_escape')
        comment = str(comment.encode('unicode_escape'),"utf-8")
        if news.comment != comment:
            news.comment = comment
            news.save()

    return HttpResponse(json.dumps({"status":"comments are saved"}))

def if_ner_location_empty(loc):
    if loc is None or loc == "":
        return True
    else:
        return False

import os
import cv2
import numpy as np
import cv2
from captcha_solver import CaptchaSolver


solver = CaptchaSolver('2captcha', api_key='ea0cd3be18267810725c245ed65fe1a1')
CAPTCHA_IMAGE_FOLDER = "captcha_recognition/generated_captcha_images/"

def compare(img):
    nparr = np.fromstring(img, np.uint8)
    captcha = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    for (i, captcha_image_file) in enumerate(os.listdir(CAPTCHA_IMAGE_FOLDER)):
        if not captcha_image_file.endswith(".png"):
            continue
        filename = CAPTCHA_IMAGE_FOLDER+captcha_image_file
        image = cv2.imread(filename)
        answer = captcha_image_file[:-4]

        if True:
            try:
                difference = cv2.subtract(captcha, image)
                result = not np.any(difference)
                if result:
                    return answer
            except:
                pass

def twocaptcha(img):
    answer = solver.solve_captcha(img)
    return answer

def predict(captcha):
    cap = twocaptcha(captcha)
    if not cap == None:
        print("matched CAPTCHA text is: {}".format(cap))
        return cap
    else:
        return ""
       #try:
        #   ans = twocaptcha(captcha)
         #  print("predicted CAPTCHA text is: {}".format(ans))
          # return ans
       
       #except Exception as e:
        #   return ""

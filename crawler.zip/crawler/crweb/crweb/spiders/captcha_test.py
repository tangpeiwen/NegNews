from selenium.webdriver.firefox.options import Options
from selenium import webdriver
from captcha_recognition import captcha_recognition
import base64
import time

def __init__(self,compNum=None,*args, **kwargs):
    super(Check_Exist_Spider, self).__init__(*args, **kwargs)
    self.compNum = compNum
    options = Options()
    options.add_argument('--headless')
    self.driver = webdriver.Firefox(options=options)
    self.retry = 3
    self.login_success = False

def start_requests(self):
    self.driver.get("https://www.icris.cr.gov.hk/normal.html")
    main_window_handle = None

    while not main_window_handle:
        main_window_handle = self.driver.current_window_handle

    #driver.save_screenshot("screenshot1.png")
    u_button = self.driver.find_element_by_xpath('''//a[@href="javascript:loginIguest(\'i\');"]''')
    u_button.click()

    signin_window_handle = None
    while not signin_window_handle:
        for handle in self.driver.window_handles:
            if handle != main_window_handle:
                self.driver.switch_to.window(handle)
                time.sleep(2)
                if self.driver.current_url == "https://www.icris.cr.gov.hk/csci/login_i.jsp":
                    signin_window_handle = handle
                    break

    while not self.login_success and self.retry:
        time.sleep(2)
        img_base64 = self.driver.execute_script("""
            var ele = arguments[0];
            var cnv = document.createElement('canvas');
            cnv.width = ele.width; cnv.height = ele.height;
            cnv.getContext('2d').drawImage(ele, 0, 0);
            return cnv.toDataURL('image/jpeg').substring(22);
            """, self.driver.find_element_by_id('CaptchaCode'))

        captcha = captcha_recognition.predict(base64.b64decode(img_base64))

        CHKBOX_09 = self.driver.find_element_by_id("CHKBOX_09")
        self.driver.execute_script("arguments[0].click();", CHKBOX_09)
        self.driver.find_element_by_id("txt_acscode").send_keys(captcha)
        login_button = self.driver.find_element_by_xpath('''//input[@value = 'Accept, Submit & Login']''')
        self.driver.execute_script("arguments[0].click();", login_button)
        time.sleep(2)
        if self.WRONG_VERIFICATION in self.driver.find_element_by_tag_name("body").text:
            back_button = self.driver.find_element_by_xpath('''//input[@onclick="javascript:history.go(-1);"]''')
            back_button.click()
            self.retry -= 1
            print("wrong captcha...retrying...{} try left".format(self.retry))
        else:
            self.login_success = True


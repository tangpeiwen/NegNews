from Cython.Distutils import build_ext
from distutils.core import Extension, setup

ext_modules = [
    Extension("check_comp_exist", ["check_comp_exist.py"]),
    Extension("cr_pageinfo_spider", ["cr_pageinfo_spider.py"]),
    Extension("cr_spider", ["cr_spider.py"]),
    Extension("download_spider", ["download_spider.py"]),
    # Extension("api4", ["api4.py"]),
    # Extension("set_paras", ["set_paras.py"]),
]

for e in ext_modules:
    e.cython_directives = {"language_level": "3"}

setup(
    name="crawler",
    version="0.1.0a0",
    description="Pins Capital",
    cmdclass={"build_ext": build_ext},
    ext_modules=ext_modules,
)
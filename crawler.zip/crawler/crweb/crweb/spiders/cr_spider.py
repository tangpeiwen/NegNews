# coding=utf-8
import scrapy
import re
import sqlite3
import os
import time
import base64
from selenium.webdriver.firefox.options import Options
from selenium import webdriver
from PIL import Image
from captcha_recognition import captcha_recognition
from io import BytesIO
import time
import lxml.html

class CR_Spider(scrapy.Spider):
    # spider name
    name = "company_registry"

    # =================Constant==================
    SEARCH_SUCC = "Welcome to ICRIS!"
    WRONG_VERIFICATION = "Incorrect VERIFICATION CODE entered."
    SEARCH_CONC = "Sorry, concurrent access is not allowed!"
    SHOPCART_SUCC = "The item you just ordered has been successfully added to your shopping cart."
    # 文件名均保持小写
    COI = "certificate of incorporation"
    NAR1 = "annual return"
    MAndA = "memorandum & articles"
    AAndA = "articles of association"
    LOW_BALANCE = 50
    # =================regular expression==================
    set_cookie_p = re.compile(r'JSESSIONID=(.*); path=/')
    set_route_p = re.compile(r'ROUTEID=\.(.*); path=/')
    cookie_p = re.compile(r'.*JSESSIONID=(.*)')
    route_p = re.compile(r'.*ROUTEID=\.(.*)')
    # 因为barcode每次的位置可能不同，需要不同的正则表达式搜索。file_no_p_1表示barcode在所查找字符串的非结尾部分，file_no_p_２为结尾部分
    file_no_p_1 = re.compile(r'.*barcode=([a-zA-Z\d]+)&')
    file_no_p_2 = re.compile(r'.*barcode=(.+)')
    file_date_p = re.compile(r'')
    # 生成数字型余额和总金额
    recipt_amount = re.compile(r'(.\d*)\.')
    balance_p = re.compile(r'HK\$(.*)\.')
    # 查看是否需要翻页
    cur_file_count = re.compile(r'Displaying: Record (\d+) to')
    total_file_count = re.compile(r'of (\d+) records\.')
    # ==================public variables==================
    cookie = ""
    worker = ""
    next_url = ""
    comp_name = ""
    # file_state = {COI: False, NAR1: False, MAndA: False, FNNC1: False}
    # file_state = {NAR1: False, MAndA: False, FNNC1: False}
    # file_state = {NAR1: False, Certificate of Incorporation:False }
    nar1_file_state = {NAR1: False}
    coi_ma_file_state = {COI: False, MAndA: False, AAndA: False}
    stop_track_other_file = False
    succ_file_num = 0
    all_file_succ = False
    # {0000000:["IOC",False]},该dict存放该公司所需爬取文件的文件名，编号和放入购物车状态。键为文件名，值为一个list,list[0]是文件编号，
    # list[1]是放入购物车状态，即当所有文件放入购物车状态都为True时，才会执行付费动作。
    comp_file_dict = dict()
    cr_no = ""
    # 当获取了订单号之后，要将订单号与公司名称对应，防止在下载时文件对应不到公司名称
    comp_name_with_reciptID = dict()
    # 订单号
    recipt_num = ""
    # 数据库路径
    db_path = "/root/NegNews/predeploy/data/db/gov/order.db"
    # 临时文件
    temp_file ="/root/NegNews/predeploy/data/contents/tempfile/buy/"
    # 账号数据库
    account_db = "/root/NegNews/predeploy/data/static/account.db"

    account = ""

    password = ""

    account_balance = 0

    # Code
    BUYSUCC = 200
    DUPLOGIN = 401
    LOGINFAIL = 402
    NOCOMP = 403
    SEARCHCOMPFAIL = 404
    SEARCHCOMPFILEFAIL = 405
    SHOPCARTFAIL = 406
    CHECKOUTFAIL = 407
    LOWBALANCE = 408
    GETORDERIDFAIL = 409
    BUYFAIL = 410

    def __init__(self,compname=None,crnumber=None,*args, **kwargs):
        super(CR_Spider, self).__init__(*args, **kwargs)
        self.comp_name = compname
        self.cr_no = crnumber
        options = Options()
        options.add_argument('--headless')
        self.driver = webdriver.Firefox(options=options)
        self.retry = 3
        self.login_success = False

    def start_requests(self):
        if self.get_icris_account():
            self.driver.get("https://www.icris.cr.gov.hk/normal.html")
            main_window_handle = None

            while not main_window_handle:
                main_window_handle = self.driver.current_window_handle

            #driver.save_screenshot("screenshot1.png")
            u_button = self.driver.find_element_by_xpath('''//a[@href="javascript:loginSubscriber(\'s\');"]''')
            u_button.click()

            signin_window_handle = None
            while not signin_window_handle:
                for handle in self.driver.window_handles:
                    if handle != main_window_handle:
                        self.driver.switch_to.window(handle)
                        time.sleep(2)
                        if self.driver.current_url == "https://www.icris.cr.gov.hk/csci/login_s.jsp":
                            signin_window_handle = handle
                            break

            while not self.login_success and self.retry:
                time.sleep(2)
                # element = self.driver.find_element_by_id('CaptchaCode').screenshot_as_png # find part of the page you want image of
                # im = Image.open(BytesIO(element))
                # im.save("captcha.png")
                #
                # try:
                #     start_time = time.time()
                #     captcha = self.solver.solve_captcha(element)
                #     print("--- %s ---\n--- %s seconds ---" % (captcha,time.time() - start_time))
                # except:
                #     self.retry -= 1
                #     print("cannot identify captcha...retrying...{} try left".format(self.retry))
                #     continue
                img_base64 = self.driver.execute_script("""
                var ele = arguments[0];
                var cnv = document.createElement('canvas');
                cnv.width = ele.width; cnv.height = ele.height;
                cnv.getContext('2d').drawImage(ele, 0, 0);
                return cnv.toDataURL('image/jpeg').substring(22);
                """, self.driver.find_element_by_id('CaptchaCode'))

                captcha = captcha_recognition.predict(base64.b64decode(img_base64))

                CHKBOX_09 = self.driver.find_element_by_id("CHKBOX_09")
                self.driver.execute_script("arguments[0].click();", CHKBOX_09)
                self.driver.find_element_by_id("txt_acscode").send_keys(captcha)
                self.driver.find_element_by_name("username").send_keys(self.account)
                self.driver.find_element_by_name("password").send_keys(self.password)
                login_button = self.driver.find_element_by_xpath('''//input[@value = 'Accept, Submit & Login']''')
                self.driver.execute_script("arguments[0].click();", login_button)
                time.sleep(2)
                body_text = self.driver.find_element_by_tag_name("body").text
                if self.WRONG_VERIFICATION in body_text:
                    back_button = self.driver.find_element_by_xpath('''//input[@onclick="javascript:history.go(-1);"]''')
                    back_button.click()
                    self.retry -= 1
                    print("wrong captcha...retrying...{} try left".format(self.retry))
                elif self.SEARCH_CONC in body_text:
                    self.retry = 0
                    print("concurrent login")
                elif "Your password has been used for 3 month(s), please consider changing the password for security." in body_text:
                    self.driver.find_element_by_name("notChangePwd").click()
                    self.login_success = True
                else:
                    self.login_success = True

            if self.login_success:
                time.sleep(10)
                print(self.driver.find_element_by_tag_name("body").text)
                self.cookies = self.driver.get_cookies()
                print(self.cookies)
                self.route = self.driver.get_cookie("ROUTEID")["value"]
                self.JSESSIONID = self.driver.get_cookie("JSESSIONID")["value"]
                self.BIGip = self.driver.get_cookie("BIGipServerUXPWEB_443")["value"]
                self.next_url = "https://www.icris.cr.gov.hk/csci/docs_list.do"
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': 'https://www.icris.cr.gov.hk/csci/docs_filter_search.do',
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443='+self.BIGip+'; JSESSIONID=' + self.JSESSIONID
                           }
                search_formdata = {
                    "searchPage": "True", "crno": self.cr_no, "newSearch": "true", "doc_group": "all", "filing_year": "all"
                }
                self.driver.quit()
                yield scrapy.FormRequest(url=self.next_url,headers=headers,cookies=self.cookies,formdata=search_formdata,callback=self.parse_show_all_doc)
            else:
                self.update_icris_account()
                self.driver.quit()
                print("login failed")
                result = {"reason": "login failed"}
                self.save_result(code=self.LOGINFAIL, content=result)
        else:
            # 2020-02-17 TODO 对于找不到可用账户时的操作 bug43
            print("no account can be used")
            pass

    def parse_login(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print ("自动登录成功")
            cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
            route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
            self.cookie = self.set_cookie_p.search(cookie_src).group(1)
            print("爬取到的登录页Cookie: " + self.cookie)
            self.route = self.set_route_p.search(route_src).group(1)
            print("爬取到的登录页Route: "+self.route)
            # 下一项需要搜索公司名称
            print("已经定位到公司，cr number是:" + self.cr_no + ", 名称是:" + self.comp_name)
            print("爬取该公司全部文件名称...")
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': 'https://www.icris.cr.gov.hk/csci/docs_filter_search.do',
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            search_formdata = {
                "searchPage": "True", "crno": self.cr_no, "newSearch": "true", "doc_group": "all", "filing_year": "all"
            }
            self.next_url = "https://www.icris.cr.gov.hk/csci/docs_list.do"
            yield scrapy.FormRequest(url=self.next_url, headers=headers, formdata=search_formdata, callback=self.parse_show_all_doc)
        elif self.SEARCH_CONC in body_text:
            result = {"reason": "duplicate login"}
            self.save_result(code=self.DUPLOGIN, content=result)
            print("ERROR:重复登录被网站拒绝")
            self.update_icris_account()
        else:
            result = {"reason": "login fail"}
            self.save_result(code=self.LOGINFAIL, content=result)
            print("ERROR:自动登录失败，请检查请求体")
            self.update_icris_account()

    def parse_show_all_doc(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            if response.headers.getlist("Set-Cookie") == []:
                cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
                splited_cookie_src = cookie_src.split(";")
                for i in splited_cookie_src:
                    if "JSESSIONID=" in i:
                        self.cookie = self.cookie_p.search(i).group(1)
                        print("爬取到的展示公司文件页Cookie: " + self.cookie)
                    elif "ROUTEID" in i:
                        self.route = self.route_p.search(i).group(1)
                        print("爬取到的展示公司文件页Route: " + self.route)
            else:
                cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
                route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
                self.cookie = self.set_cookie_p.search(cookie_src).group(1)
                print("爬取到的展示公司文件页Cookie: " + self.cookie)
                self.route = self.set_route_p.search(route_src).group(1)
                print("爬取到的展示公司文件页Route: " + self.route)
            file_info_list = response.xpath('//tr[@bgcolor="#CCCCCC"]//td')
            # 只需要获取每行0(可否下载),4(文件名称),7列(文件id)的信息,
            file_num = len(file_info_list)//11
            for i in range(0,file_num):
                # 如果有下载连接，说明可下载
                if file_info_list[i*11+0].xpath('./a[@href="javascript:;"]') is not None:
                    print("查询到可下载的文件:\r")
                    # 文件名
                    file_name = file_info_list[i*11+4].xpath('text()').get().lstrip('\r\n ')
                    # 文件id
                    file_id = file_info_list[i*11+7].xpath('text()').get().lstrip('\r\n ')
                    available_status = file_info_list[i*11+10].xpath('./div/text()').get().lstrip('\r\n ')
                    print("文件是否获取："+available_status)
                    # 对文件是否要放入购物车做鉴定，目前只需要COI,NAR1,M&A文件,
                    '''
                    ***要加入爬取最新NAR1的功能
                    '''
                    # 加入判断文件日期功能，认为解析后的文件位置越靠前越新，如果遇到重名文件，按找越靠前越选择的原则，只选择最新的
                    for i in self.nar1_file_state:
                        if i in file_name.lower() and not self.nar1_file_state[i] and "available" in available_status.lower():
                            self.nar1_file_state[i] = True
                            self.stop_track_other_file = True
                            self.comp_file_dict[file_id] = [file_name,False]
                            print("需要购买"+file_name + ":" + file_id + "\r")

                    for i in self.coi_ma_file_state:
                        if i in file_name.lower() and not self.coi_ma_file_state[i] and "available" in available_status.lower():
                            self.coi_ma_file_state[i] = True
                            self.comp_file_dict[file_id] = [file_name,False]
                            print("需要购买"+file_name + ":" + file_id + "\r")

                    if not self.stop_track_other_file and "available" in available_status.lower():
                        self.comp_file_dict[file_id] = [file_name,False]
                        print("需要购买"+file_name + ":" + file_id + "\r")

            # 检测是否有下一页
            next_page = response.xpath('//td[contains(@height,"20") and contains(@colspan,"6")]//text()').get()
            next_page = next_page.strip()
            next_page = next_page.replace("\n","")
            next_page = next_page.replace("\r","")
            next_page = re.sub("\s+"," ",next_page)
            cur_count = self.cur_file_count.search(next_page).group(1)
            total_count = self.total_file_count.search(next_page).group(1)
            if int(cur_count) + 9 >= int(total_count):
                print("已经到最后一页")
                # 判定是不是NAR和FNNC都在待下载列表里，如果是则删除FNNC1
                # ifNAR = False
                # ifFNNC1 = False
                # file_id = ""
                # for fileid in self.comp_file_dict:
                #     if self.NAR1 in self.comp_file_dict[fileid][0]:
                #         ifNAR = True
                #     if self.FNNC1 in self.comp_file_dict[fileid][0]:
                #         ifFNNC1 = True
                #     if ifFNNC1 and ifNAR:
                #         file_id = fileid
                # if ifNAR and ifFNNC1:
                #     self.comp_file_dict.pop(file_id)
                for fileid in self.comp_file_dict:
                    print("将要下载文件放入购物车中...")
                    print(fileid+":"+self.comp_file_dict[fileid][0])
                    self.next_url = "https://www.icris.cr.gov.hk/csci/addProduct.do"
                    headers = {'Host': 'www.icris.cr.gov.hk',
                               'Origin': 'https://www.icris.cr.gov.hk',
                               'Referer': ' https://www.icris.cr.gov.hk/csci/docs_list.do',
                               'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                               }
                    search_formdata = {
                        "prdGrp": "RPT", "prdCd": "DOCUMENT", "media": "F", "certify": "N",
                        "desc": "document%20for%20CR%20no:" + self.cr_no + ",barCode:" + fileid,
                        "delivery": "D", "productRevCode": "44", "barcode": fileid
                    }
                    yield scrapy.FormRequest(url=self.next_url,headers=headers,formdata=search_formdata,callback=self.parse_add_to_cart,meta={"barcode":fileid},dont_filter=True)

            else:
                page_no = int(cur_count)//10 + 2
                print("即将爬取下一页："+str(page_no))
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': ' https://www.icris.cr.gov.hk/csci/cns_search.jsp',
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                search_formdata = {
                    "searchPage": "True", "docGroupInd":"all", "filingYearInd":"all", "authcrno":self.cr_no, "crno":self.cr_no, "doc_group":"all", "filing_year":"all", "PageNO":str(page_no)
                }
                self.next_url = "https://www.icris.cr.gov.hk/csci/docs_list.do"
                yield scrapy.FormRequest(url=self.next_url, headers=headers, formdata=search_formdata, callback=self.parse_show_all_doc)


        else:
            print("ERROR:查询公司文件信息失败")
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            print("数据库打开成功")
            c.execute("INSERT INTO error_comp (comp_name,reason) VALUES (\"" + self.comp_name + "\",\"查询公司文件信息失败\")");
            conn.commit()
            print("Error Company Records created successfully")
            conn.close()
            result = {"reason": "search comp file failed"}
            self.save_result(code=self.SEARCHCOMPFILEFAIL, content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

    def parse_add_to_cart(self,response):
        body_text = response.text
        if self.SHOPCART_SUCC in body_text:
            print("放入购物车成功,barcode:"+response.meta["barcode"])
            request_body = response.request.body.decode("utf-8")
            # 获取该加入购物车的文件号，在文件dict中更改成功状态
            try:
                file_no = self.file_no_p_1.search(request_body).group(1)
            except AttributeError as e:
                print("解析barcode失败，错误如下，重新解析中...")
                print(e)
                file_no = self.file_no_p_2.search(request_body).group(1)
            print("解析的file_no:"+file_no)
            for i in self.comp_file_dict:
                if i == file_no:
                    self.comp_file_dict[i][1] = True
                    self.succ_file_num += 1
            # 等待所有文件均成功放入购物车后决定付费
            print("成功加入购物车的文件数量："+str(self.succ_file_num)+"  总数为："+str(len(self.comp_file_dict)))
            if self.succ_file_num == len(self.comp_file_dict):
                self.all_file_succ = True
            # 如果所有要下载文件均放入购物车，启动购买流程
            if self.all_file_succ:
                print(self.comp_file_dict)
                print("============================")
                print("所有文件均放入购物车，启动购买进程")
                print("============================")
                # 进入checkout进程
                print("爬取到的展示公司文件页Cookie: " + self.cookie)
                print("爬取到的展示公司文件页Route: " + self.route)
                self.next_url = "https://www.icris.cr.gov.hk/csci/cart_shoppingcartmaintenance.do"
                headers = {'Host': 'www.icris.cr.gov.hk',
                           # 'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': 'https://www.icris.cr.gov.hk/csci/download.do',
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                yield scrapy.Request(url=self.next_url,headers=headers,callback=self.parse_checkout)
                # print("准备登出,tag=succ,reason=all file in shopping cart")
                # conn = sqlite3.connect('/home/calvin/Documents/Pingan/VB/crawler/crweb/order.db')
                # c = conn.cursor()
                # print("数据库打开成功")
                # c.execute("INSERT INTO order_comp (orderid,comp_name) VALUES (\"" + self.recipt_num + "\",\"" + self.comp_name + "\")");
                # conn.commit()
                # print("Success Buy Records created successfully")
                # conn.close()
                #headers = {'Host': 'www.icris.cr.gov.hk',
                #       'Origin': 'https://www.icris.cr.gov.hk',
                #       'Referer': self.next_url,
                #       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                #       }
                #self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
                #yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

        else:
            print("放入购物车失败,barcode是:"+response.meta["barcode"])
            # 由于文件特别多，可能出现某个文件放入购物车失败。为了不影响整个的进程，对放入购物车失败不进行后续记录
            # conn = sqlite3.connect(self.db_path)
            # c = conn.cursor()
            # print("数据库打开成功")
            # c.execute("INSERT INTO error_comp (comp_name,reason) VALUES (\"" + self.comp_name + "\",\"放入购物车失败\")");
            # conn.commit()
            # print("Error Company Records created successfully")
            # conn.close()
            # result = {"reason": "put into shop cart failed"}
            # self.save_result(code=self.SHOPCARTFAIL, content=result)
            print("将失败文件重新放入购物车中...")
            print(response.meta["barcode"] + ":" + self.comp_file_dict[response.meta["barcode"]][0])
            self.next_url = "https://www.icris.cr.gov.hk/csci/addProduct.do"
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': ' https://www.icris.cr.gov.hk/csci/docs_list.do',
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            search_formdata = {
                "prdGrp": "RPT", "prdCd": "DOCUMENT", "media": "F", "certify": "N",
                "desc": "document%20for%20CR%20no:" + self.cr_no + ",barCode:" + response.meta["barcode"],
                "delivery": "D", "productRevCode": "44", "barcode": response.meta["barcode"]
            }
            time.sleep(10)
            yield scrapy.FormRequest(url=self.next_url, headers=headers, formdata=search_formdata,
                                     callback=self.parse_add_to_cart, meta={"barcode": response.meta["barcode"]},dont_filter=True)


    def parse_checkout(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print("checkout文件成功")
            if response.headers.getlist("Set-Cookie") == []:
                cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
                splited_cookie_src = cookie_src.split(";")
                for i in splited_cookie_src:
                    if "JSESSIONID=" in i:
                        self.cookie = self.cookie_p.search(i).group(1)
                        print("爬取到的checkout页Cookie: " + self.cookie)
                    elif "ROUTEID" in i:
                        self.route = self.route_p.search(i).group(1)
                        print("爬取到的checkout页Route: " + self.route)
            else:
                cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
                route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
                self.cookie = self.set_cookie_p.search(cookie_src).group(1)
                print("爬取到的checkout页Cookie: " + self.cookie)
                self.route = self.set_route_p.search(route_src).group(1)
                print("爬取到的checkout页Route: " + self.route)
            # 检查文件数量,没问题的话进入下一个页面
            '''
            该检测方法只适用于单进程。单用户demo使用，多人使用时会出现要下载文件数量和购物车中不一样的情况，这时需要定位精准文件名
            '''
            file_count = 0
            for i in self.comp_file_dict:
                if i[0] in body_text:
                    file_count += 1
            if file_count == len(self.comp_file_dict):
                # 进行下一页
                print("检查需要购买文件数量和所需数量一致，准备获取订单号...")
                self.next_url = "https://www.icris.cr.gov.hk/csci/showOrderInfo.do"
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': 'https://www.icris.cr.gov.hk/csci/ShoppingCardSaveAndCheckOut.do',
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                search_formdata = {
                    "showOrderInfo":"true","toPay":"true","fromShoppingCart":"true","prodCode":"DOCUMENT"
                }
                yield scrapy.FormRequest(url=self.next_url,headers=headers,formdata=search_formdata,callback=self.parse_show_order_info)
            else:
                print("ERROR:检查需要购买文件数量和所需不一致，停止购买流程")
                conn = sqlite3.connect(self.db_path)
                c = conn.cursor()
                print("数据库打开成功")
                c.execute("INSERT INTO error_comp (comp_name,reason) VALUES (\"" + self.comp_name + "\",\"检查需要购买文件数量和所需不一致，停止购买流程\")");
                conn.commit()
                print("Error Company Records created successfully")
                conn.close()
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': self.next_url,
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
                yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)
        else:
            print("ERROR:checkout购物车失败")
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            print("数据库打开成功")
            c.execute(
                "INSERT INTO error_comp (comp_name,reason) VALUES (\"" + self.comp_name + "\",\"checkout购物车失败\")");
            conn.commit()
            print("Error Company Records created successfully")
            conn.close()
            result = {"reason": "checkout fail"}
            self.save_result(code=self.CHECKOUTFAIL, content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

    def parse_show_order_info(self,response):
        body_text = response.text
        #print ('order info***********:' + response.text)
        if self.SEARCH_SUCC in body_text:
            print("获取订单号成功")
            if response.headers.getlist("Set-Cookie") == []:
                cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
                splited_cookie_src = cookie_src.split(";")
                for i in splited_cookie_src:
                    if "JSESSIONID=" in i:
                        self.cookie = self.cookie_p.search(i).group(1)
                        print("爬取到的显示购买文件列表页Cookie: " + self.cookie)
                    elif "ROUTEID" in i:
                        self.route = self.route_p.search(i).group(1)
                        print("爬取到的显示购买文件列表页Route: " + self.route)
            else:
                cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
                route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
                self.cookie = self.set_cookie_p.search(cookie_src).group(1)
                print("爬取到的显示购买文件列表页Cookie: " + self.cookie)
                self.route = self.set_route_p.search(route_src).group(1)
                print("爬取到的显示购买文件列表页Route: " + self.route)
            # 获取到订单信息
            #recipt_infos = response.xpath('//td[@width="70%"]')
            try:
                recipt_table = lxml.html.fromstring(body_text)
                recipt_table = recipt_table.xpath('''//table[.//*[contains(text(), "Order No")]]''')
                recipt_table = recipt_table[-1]
                self.recipt_num = recipt_table.getchildren()[0].getchildren()[1].text
                print ("订单号是:"+self.recipt_num)
                recipt_price_int = int(float(recipt_table.getchildren()[1].getchildren()[1].text))
                print ("订单金额是:",recipt_price_int)
                # recipt_price_str = recipt_infos[1].xpath('text()').get()
                # recipt_price_int = int(self.recipt_amount.search(recipt_price_str).group(1))
            except Exception as e:
                print(e)
                result = {"reason": "checkout failed"}
                self.save_result(code=self.CHECKOUTFAIL, content=result)
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': self.next_url,
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
                yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

            # 获取到当前余额
            # 2020-02-17 TODO 将balance转为数字
            balance = response.xpath('//td[contains(@colspan,"3") and contains(@width,"80%")]//text()').getall()[1]
            balance_str = self.balance_p.search(balance).group(1)
            balance_int = int(balance_str.replace(",",""))
            if balance_int < recipt_price_int:
                print("余额不够，请充值！当前余额为:"+balance_str)
                conn = sqlite3.connect(self.db_path)
                c = conn.cursor()
                print("数据库打开成功")
                c.execute("INSERT INTO error_comp (comp_name,reason) VALUES (\"" + self.comp_name + "\",\"余额不够，请充值\")");
                conn.commit()
                print("Error Company Records created successfully")
                conn.close()
                result = {"reason": "low balance"}
                self.save_result(code=self.LOWBALANCE, content=result)
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': self.next_url,
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
                yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)
            else:
                print("余额充足，开始购买所选文件，当前余额为:"+str(balance_int))
                #进行购买
                self.next_url = "https://www.icris.cr.gov.hk/csci/shoppingCartPayForSub.do"
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Origin': 'https://www.icris.cr.gov.hk',
                           'Referer': ' https://www.icris.cr.gov.hk/csci/showOrderInfo.do',
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                           }
                search_formdata = {
                    "orderNo": self.recipt_num, "toPay": "true", "fromShoppingCart": "true"
                }
                yield scrapy.FormRequest(url=self.next_url,headers=headers,formdata=search_formdata,callback=self.parse_buy)
        else:
            print("ERROR:获取订单号失败!")
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            print("数据库打开成功")
            c.execute("INSERT INTO error_comp (comp_name,reason) VALUES (\"" + self.comp_name + "\",\"获取订单号失败\")");
            conn.commit()
            print("Error Company Records created successfully")
            conn.close()
            result = {"reason": "get order id fail"}
            self.save_result(code=self.GETORDERIDFAIL, content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)


    def parse_buy(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print ("购买成功，该公司的文件需等到几分钟方可执行文件下载爬虫。多谢配合。")
            print ("准备登出，等待几分钟后执行下载文件爬虫")
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            print("数据库打开成功")
            c.execute("INSERT INTO order_comp (orderid,comp_name) VALUES (\"" + self.recipt_num + "\",\"" + self.comp_name + "\")");
            conn.commit()
            print("Success Buy Records created successfully")
            conn.close()
            result = {"reason":"Buy Successfully.","orderId":self.recipt_num}
            self.save_result(code=self.BUYSUCC,content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)
        else:
            print ("购买失败，请登录网站查看订单信息。")
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            print("数据库打开成功")
            c.execute("INSERT INTO error_comp (comp_name,reason) VALUES (\"" + self.comp_name + "\",\"购买失败，请登录网站查看订单信息\")");
            conn.commit()
            print("Error Company Records created successfully")
            conn.close()
            result = {"reason": "buy order fail"}
            self.save_result(code=self.BUYFAIL, content=result)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)


    def parse_logout(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            self.update_icris_account()
            print("登出成功，爬虫即将结束程序。")
        else:
            # 登出失败，账号不要变更状态，否则会出现其他使用者无法正常使用该账号状态。
            print("登出失败，需要人工通过postman登出网站.公司名称:"+self.comp_name)

    '''
    2020-02-17
    zhangchi
    desc:增加使用加密数据库进行账户的存取
    '''
    def get_icris_account(self):
        conn = sqlite3.connect(self.account_db)
        cursor = conn.execute("SELECT username, password FROM icris WHERE balance>"+str(self.LOW_BALANCE))#WHERE status=0 AND balance>
        records = list(cursor)
        if len(records) != 0:
            self.account = records[0][0]
            self.password = records[0][1]
            conn.execute("UPDATE icris SET status = 1 WHERE username='"+self.account+"'")
            conn.commit()
            conn.close()
            return True
        else:
            conn.close()
            return False

    def update_icris_account(self):
        conn = sqlite3.connect(self.account_db)
        # 2020-02-17 TODO 由于还未将余额检测功能补齐，或者由于还没有查询到余额就出错的情况，只更新status
        # TODO 对于后面加入余额检测功能时，需要加入判定是购买成功还是购买失败，购买失败不更新balance
        if self.account_balance != 0:
            conn.execute("UPDATE icris SET status = 2, balance=" +
                str(self.account_balance) + " WHERE username='" + self.account + "'")
            conn.commit()
            conn.close()
        else:
            conn.execute("UPDATE icris SET status = 0 WHERE username='" + self.account + "'")
            conn.commit()
            conn.close()
        self.account = ""
        self.password = ""
        self.account_balance = 0

    def save_result(self,code=None,content=None):
        print("保存购买状态到文件："+str(content))
        f = open(self.temp_file + self.comp_name, 'w')
        f.write(str({"code":code,"content":content,"type":"buy"}))
        f.close()

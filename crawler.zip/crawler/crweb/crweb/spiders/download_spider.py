# coding=utf-8
import scrapy
import re
import os
import sqlite3
import zipfile
import json
import time
import shutil
import base64
from selenium.webdriver.firefox.options import Options
from selenium import webdriver
from PIL import Image
from captcha_recognition import captcha_recognition
from io import BytesIO
import time

class Download_Spider(scrapy.Spider):

    name = "company_registry_downloader"

    # =================Constant==================
    SEARCH_SUCC = "Welcome to ICRIS!"
    WRONG_VERIFICATION = "Incorrect VERIFICATION CODE entered."
    SEARCH_CONC = "Sorry, concurrent access is not allowed!"
    # =================regular expression==================
    set_cookie_p = re.compile(r'JSESSIONID=(.*); path=/')
    set_route_p = re.compile(r'ROUTEID=\.(.*); path=/')
    cookie_p = re.compile(r'.*JSESSIONID=(.*)')
    route_p = re.compile(r'.*ROUTEID=\.(.*)')
    file_path_p = re.compile(r'<a href="#" onclick=\'javascript:resetDelay\(\); window\.open\("(.*)",')
    # ==================public variables==================
    cookie = ""
    worker = ""
    next_url = ""
    order_no = ""
    comp_name = ""
    file_num = 0

    download_root_path = "/home/ubuntu/NegNews/predeploy/data/contents/gov/"
    db_path = "/home/ubuntu/NegNews/predeploy/data/db/gov/order.db"
    # 账号数据库
    account_db = "/home/ubuntu/NegNews/predeploy/data/static/account.db"
    download_files = []
    results = {"result": []}
    account = ""

    password = ""
    # temp file
    TEMP_FILE ="/home/ubuntu/NegNews/predeploy/data/contents/tempfile/download/"
    # Code
    DOWNLOADSUCC = 200
    DUPLOGIN = 401
    LOGINFAIL = 402
    GETORDERFAIL = 403
    GETDOWNLOADLISTFAIL = 404



    def __init__(self,compname=None,orderno=None,*args, **kwargs):
        super(Download_Spider, self).__init__(*args, **kwargs)
        self.comp_name = compname
        self.order_no = orderno
        options = Options()
        options.add_argument('--headless')
        self.driver = webdriver.Firefox(options=options)
        self.retry = 3
        self.login_success = False
        print("=========================================")
        print("公司名称:"+self.comp_name+"; 订单ID:"+self.order_no)
        print("=========================================")

    def start_requests(self):
        if self.get_icris_account():
            self.driver.get("https://www.icris.cr.gov.hk/normal.html")
            main_window_handle = None

            while not main_window_handle:
                main_window_handle = self.driver.current_window_handle

            #driver.save_screenshot("screenshot1.png")
            time.sleep(5)
            u_button = self.driver.find_element_by_xpath('''//a[@href="javascript:loginSubscriber(\'s\');"]''')
            u_button.click()

            signin_window_handle = None
            while not signin_window_handle:
                for handle in self.driver.window_handles:
                    if handle != main_window_handle:
                        self.driver.switch_to.window(handle)
                        time.sleep(2)
                        if self.driver.current_url == "https://www.icris.cr.gov.hk/csci/login_s.jsp":
                            signin_window_handle = handle
                            break

            while not self.login_success and self.retry:
                time.sleep(2)
                # element = self.driver.find_element_by_id('CaptchaCode').screenshot_as_png # find part of the page you want image of
                # im = Image.open(BytesIO(element))
                # im.save("captcha.png")
                #
                # try:
                #     start_time = time.time()
                #     captcha = self.solver.solve_captcha(element)
                #     print("--- %s ---\n--- %s seconds ---" % (captcha,time.time() - start_time))
                # except:
                #     self.retry -= 1
                #     print("cannot identify captcha...retrying...{} try left".format(self.retry))
                #     continue
                img_base64 = self.driver.execute_script("""
                var ele = arguments[0];
                var cnv = document.createElement('canvas');
                cnv.width = ele.width; cnv.height = ele.height;
                cnv.getContext('2d').drawImage(ele, 0, 0);
                return cnv.toDataURL('image/jpeg').substring(22);
                """, self.driver.find_element_by_id('CaptchaCode'))

                captcha = captcha_recognition.predict(base64.b64decode(img_base64))

                CHKBOX_09 = self.driver.find_element_by_id("CHKBOX_09")
                self.driver.execute_script("arguments[0].click();", CHKBOX_09)
                txt_acscode = self.driver.find_element_by_id("txt_acscode")
                txt_acscode.clear()
                txt_acscode.send_keys(captcha)
                username = self.driver.find_element_by_name("username")
                username.clear()
                username.send_keys(self.account)
                pwd = self.driver.find_element_by_name("password")
                pwd.clear()
                pwd.send_keys(self.password)
                login_button = self.driver.find_element_by_xpath('''//input[@value = 'Accept, Submit & Login']''')
                self.driver.execute_script("arguments[0].click();", login_button)
                time.sleep(2)
                body_text = self.driver.find_element_by_tag_name("body").text
                if self.WRONG_VERIFICATION in body_text:
                    back_button = self.driver.find_element_by_xpath('''//input[@onclick="javascript:history.go(-1);"]''')
                    back_button.click()
                    self.retry -= 1
                    print("wrong captcha...retrying...{} try left".format(self.retry))
                elif self.SEARCH_CONC in body_text:
                    self.retry = 0
                    print("concurrent login")
                elif "Your password has been used for 3 month(s), please consider changing the password for security." in body_text:
                    self.driver.find_element_by_name("notChangePwd").click()
                    self.login_success = True
                else:
                    self.login_success = True

            if self.login_success:
                time.sleep(10)
                print(self.driver.find_element_by_tag_name("body").text)
                self.cookies = self.driver.get_cookies()
                print(self.cookies)
                self.route = self.driver.get_cookie("ROUTEID")["value"]
                self.JSESSIONID = self.driver.get_cookie("JSESSIONID")["value"]
                self.BIGip = self.driver.get_cookie("BIGipServerUXPWEB_443")["value"]
                self.next_url = "https://www.icris.cr.gov.hk/csci/download.do"
                headers = {'Host': 'www.icris.cr.gov.hk',
                           'Referer': 'https://www.icris.cr.gov.hk/csci/docs_filter_search.do',
                           'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443='+self.BIGip+'; JSESSIONID=' + self.JSESSIONID
                           }
                self.driver.quit()
                yield scrapy.Request(url=self.next_url,headers=headers,cookies=self.cookies,callback=self.parse_order_info)
            else:
                self.update_icris_account()
                self.driver.quit()
                print("login failed")
                result = {"reason": "login failed"}
                self.save_result(code=self.LOGINFAIL, content=result)
        else:
            # 2020-02-17 TODO 对于找不到可用账户时的操作 bug43
            print("no account can be used")
            pass

    def parse_login(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print("自动登录成功")
            cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
            route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
            self.cookie = self.set_cookie_p.search(cookie_src).group(1)
            print("爬取到的登录页Cookie: " + self.cookie)
            self.route = self.set_route_p.search(route_src).group(1)
            print("爬取到的登录页Route: " + self.route)
            self.next_url = "https://www.icris.cr.gov.hk/csci/download.do"
            headers = {
                'Host': 'www.icris.cr.gov.hk',
                'Referer': 'https://www.icris.cr.gov.hk/csci/login_s.do',
                'Cookie': 'web.country=US; web.language=en; ROUTEID=.'+self.route+'; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID='+self.cookie
            }
            yield scrapy.Request(url=self.next_url,headers=headers,callback=self.parse_order_info)
        elif self.SEARCH_CONC in body_text:
            result = {"reason": "duplicate login"}
            self.save_result(code=self.DUPLOGIN)
            print("ERROR:重复登录被网站拒绝")
            self.update_icris_account()
        else:
            result = {"reason": "login fail"}
            self.save_result(code=self.LOGINFAIL)
            print("ERROR:自动登录失败，请检查请求体")
            self.update_icris_account()

    def parse_order_info(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print("获取已购买的order列表成功")
            time.sleep(10)
            print("\n\n\n set cookie\n\n\n",response.headers.getlist("Set-Cookie"))
            print("\n\n\n cookie\n\n\n",response.request.headers.getlist('Cookie'))
            # if response.headers.getlist("Set-Cookie") == []:
            cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
            splited_cookie_src = cookie_src.split(";")
            for i in splited_cookie_src:
                if "JSESSIONID=" in i:
                    self.cookie = self.cookie_p.search(i).group(1)
                    print("爬取到的order详情页Cookie: " + self.cookie)
                elif "ROUTEID" in i:
                    self.route = self.route_p.search(i).group(1)
                    print("爬取到的order详情页Route: " + self.route)
            # else:
            #     cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
            #     route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
            #     self.cookie = self.set_cookie_p.search(cookie_src).group(1)
            #     print("爬取到的order详情页Cookie: " + self.cookie)
            #     self.route = self.set_route_p.search(route_src).group(1)
            #     print("爬取到的order详情页Route: " + self.route)

            order_list = response.xpath('//form[@name = "cmm_order_type"]//td//font/text()').getall()
            order_quantity = len(order_list)//3
            print("获取order数量:"+str(order_quantity))
            order_date = ''
            expire_date = ''
            for i in range(0,order_quantity):
                if order_list[3*i+1].lstrip('\r\n\xa0 ') == self.order_no:
                    print("查找到该公司的order,准备下载")
                    order_date = order_list[3*i+0].lstrip('\r\n\xa0 ')
                    expire_date = order_list[3*i+2].lstrip('\r\n\xa0 ')
            # 进入下载页面
            headers = {
                'Host': 'www.icris.cr.gov.hk',
                'Origin': ' https://www.icris.cr.gov.hk',
                'Referer': ' https://www.icris.cr.gov.hk/csci/download.do',
                'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
            }
            formdata = {
                'orderNo': self.order_no, 'expiryDate': expire_date, 'orderDate': order_date
            }
            self.next_url = 'https://www.icris.cr.gov.hk/csci/downloadItems.do'
            yield scrapy.FormRequest(url=self.next_url,headers=headers,formdata=formdata,callback=self.parse_download_info)
        else:
            result = {"reason": "get orderid failed"}
            self.save_result(code=self.GETORDERFAIL)
            print("获取order失败")

    def parse_download_info(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            print("获取下载文件列表成功")
            time.sleep(10)
            print("\n\n\n set cookie\n\n\n",response.headers.getlist("Set-Cookie"))
            print("\n\n\n cookie\n\n\n",response.request.headers.getlist('Cookie'))
            # if response.headers.getlist("Set-Cookie") == []:
            cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
            splited_cookie_src = cookie_src.split(";")
            for i in splited_cookie_src:
                if "JSESSIONID=" in i:
                    self.cookie = self.cookie_p.search(i).group(1)
                    print("爬取到的文件下载页Cookie: " + self.cookie)
                elif "ROUTEID" in i:
                    self.route = self.route_p.search(i).group(1)
                    print("爬取到的文件下载页Route: " + self.route)
            # else:
            #     cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
            #     route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
            #     self.cookie = self.set_cookie_p.search(cookie_src).group(1)
            #     print("爬取到的文件下载页Cookie: " + self.cookie)
            #     self.route = self.set_route_p.search(route_src).group(1)
            #     print("爬取到的文件下载页Route: " + self.route)
            downloaded_files = response.xpath('//a[contains(@href,"#") and contains(@onclick,"javascript:resetDelay()")]')
            print("需要下载文件数量为："+str(len(downloaded_files)))
            urls = []
            for file in downloaded_files:
                filename = file.xpath('./font[@class="coyname2"]/text()').get()
                #避免下载重复
                if filename not in self.download_files:
                    self.file_num += 1
                    print("需要下载的文件个数："+str(self.file_num))
                    self.download_files.append(filename)
                    url = self.file_path_p.search(file.get()).group(1)
                    url = url.replace("&amp;","&")
                    url = url.rstrip('", "')
                    urls.append(url)
                    # 进行下载
                    headers = {
                        'Host': 'www.icris.cr.gov.hk',
                        'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie,
                        'Filename': filename
                    }
                    result = {"doc_name":filename,"doc_file_location":self.download_root_path+self.comp_name+"/"+filename+"(1)/","return_code":200,"type":"download"}
                    yield scrapy.Request(url=url,headers=headers,callback=self.parse_download,meta=result)
            # item = CrwebItem()
            # item['file_url'] = urls
            # return item
        else:
            result = {"reason": "get download list fail"}
            self.save_result(code=self.GETDOWNLOADLISTFAIL)
            print("获取下载文件列表失败")

    def parse_download(self,response):
        # body_text = response.text
        self.results["result"].append(response.meta)
        filename = response.request.headers.getlist("Filename")[0].decode("utf-8")
        print("需要下载的文件："+filename)
        # 对于每个新的公司创建一个新的文件夹存放文件
        if not os.path.exists(self.download_root_path+self.comp_name+"/"+filename+"(1)"):
            os.makedirs(self.download_root_path+self.comp_name+"/"+filename+"(1)")
        else:
            shutil.rmtree(self.download_root_path+self.comp_name+"/"+filename+"(1)")
            os.makedirs(self.download_root_path + self.comp_name + "/" + filename + "(1)")
        f = open(self.download_root_path+self.comp_name+"/"+filename,'wb')
        f.write(response.body)
        # unzip
        zFile = zipfile.ZipFile(self.download_root_path+self.comp_name+"/"+filename,'r')
        for file in zFile.namelist():
            zFile.extract(file,self.download_root_path+self.comp_name+"/"+filename+"(1)")
        self.file_num -= 1
        print("需要下载的文件个数：" + str(self.file_num))
        # 说明所有文件下载完毕
        if self.file_num == 0:
            print("所有文件下载完毕")
            conn = sqlite3.connect(self.db_path)
            c = conn.cursor()
            c.execute("update order_comp set ifdownloaded = \"True\" where orderid=\""+self.order_no+"\"")
            conn.commit()
            print("更新order数据库成功")
            self.save_result(code=self.DOWNLOADSUCC, content=self.results)
            conn.close()
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie': 'web.country=US; web.language=en; ROUTEID=.' + self.route + '; BIGipServerUXPWEB_443=175337994.47873.0000; JSESSIONID=' + self.cookie
                       }
            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

    def parse_logout(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            self.update_icris_account()
            print("登出成功，爬虫即将结束程序。")
        else:
            print("登出失败，需要人工通过postman登出网站.")

    '''
    2020-02-17
    zhangchi
    desc:增加使用加密数据库进行账户的存取,对于下载文件来说，需要用和购买的账号来进行下载。所以涉及到多账号问题，在后续进行更新。
    下载程序对应的账号初始状态应该为2(在多账号修改前为0)，使用时将状态置位1，使用完之后将状态置位0，使用过程登出出错则不更改账号状态
    '''
    def get_icris_account(self):
        conn = sqlite3.connect(self.account_db)
        cursor = conn.execute("SELECT username, password FROM icris")
        records = list(cursor)
        if len(records) != 0:
            self.account = records[0][0]
            self.password = records[0][1]
            conn.execute("UPDATE icris SET status = 1 WHERE username='"+self.account+"'")
            conn.commit()
            conn.close()
            return True
        else:
            conn.close()
            return False

    def update_icris_account(self):
        conn = sqlite3.connect(self.account_db)
        # 2020-02-17 TODO 由于还未将余额检测功能补齐，或者由于还没有查询到余额就出错的情况，只更新status
        conn.execute("UPDATE icris SET status = 0 WHERE username='" + self.account + "'")
        conn.commit()
        conn.close()
        self.account = ""
        self.password = ""

    def save_result(self,code=None,content=None):
        if content is None:
            print("保存下载失败状态到文件：" + str(code))
            f = open(self.TEMP_FILE + self.order_no, 'w')
            f.write(json.dumps({"result":code}))
            f.close()
        else:
            print("保存下载状态到文件：" + str(content))
            f = open(self.TEMP_FILE + self.order_no, 'w')
            f.write(json.dumps(content))
            f.close()

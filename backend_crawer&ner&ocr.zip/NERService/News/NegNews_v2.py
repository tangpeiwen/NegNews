from textblob import TextBlob
import csv
import spacy
from csvtotable import convert
import os

class NewsJudge():
    def news_ana(self,input_path, output_path):

        nlp = spacy.load('en_core_web_sm')
        try:
            text = open(input_path, encoding='UTF-8', errors='ignore').read().splitlines()
        except:
            text = ""
        NumPara = 1
        NegPara = []
        neg = {}
        neg2 = {}
        ifsucc = True
        error = 0
        n = 1
        for para in text:
            try:
                blob = TextBlob(para)
                NegPoint = blob.sentiment[0]
                neg[para] = NegPoint
                TotalEnt = ''
                if NegPoint <= 0:
                    doc = nlp(para)
                    # ners = [(ent.text, ent.label_) for ent in doc.ents]
                    for ent in doc.ents:
                        if ent.label_ == 'PERSON':
                            TotalEnt = TotalEnt + ent.text + '(PERSON)\n'
                        if ent.label_ == 'FAC' or ent.label == 'GPE' or ent.label == 'LOC':
                            TotalEnt = TotalEnt + ent.text + '(LOCATION)\n'
                        if ent.label_ == 'NORP' or ent.label == 'ORG':
                            TotalEnt = TotalEnt + ent.text + '(ORGANIAZATION)\n'
                        if ent.label_ == 'DATE' or ent.label == 'TIME':
                            TotalEnt = TotalEnt + ent.text + '(TIME)\n'

                    # print(ners[0][1])
                    NegPara.append([NumPara, NegPoint, para, TotalEnt])
                neg2[para] = TotalEnt
                neg2 = {k: 'NA' if not v else v for k, v in neg2.items() }
                    #NegPoints.append(NegPoint)
                    #para.append(para)
                #neg_ana['NegPoint'] = NegPoint
                #neg_ana['ParaText'] = para
                #neg['ent'] = TotalEnt
                NumPara = NumPara + 1
            except:
                error += 1
            n = n + 1
        npara = min(neg, key=lambda key: neg[key])
        npoint = neg[npara]
        ent = neg2[npara]
        print (str(neg2))

        TotalNegPara = len(NegPara)
        if TotalNegPara > 0:
            CsvFilePath = input_path[:-3] + 'csv'
            with open(CsvFilePath, 'a+', newline='', encoding='utf8', errors='surrogatepass') as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(['NumPara', 'NegPoint', 'ParaText', 'Entity'])
                writer.writerows(NegPara)
            csvfile.close()
            content = convert.convert(CsvFilePath, delimiter=",", quotechar='"',
                                      display_length=-1, overwrite=False, serve=False, pagination=True,
                                      virtual_scroll=1000, no_header=False, export=True,
                                      export_options=["copy", "csv", "json", "print"])
            htmlFilePath = output_path
            convert.save(htmlFilePath, content)
            os.remove(CsvFilePath)
       # if NegPara != []:
       
        if error == n:
            return {"if_succ": not ifsucc, "neg_count":TotalNegPara}
        else:
            org = {"if_succ": ifsucc, "neg_count":TotalNegPara,'NegPoint':npoint, 'ParaText':npara,'Entity':ent}
            #org.update(neg_ana)
            #return {"if_succ": ifsucc, "neg_count":TotalNegPara}
            print ('*******'+str(org))
            return org
# if __name__ == "__main__":
#     ner = NewsJudge()
#     input_path = "/home/peiwentang/Documents/Pingan/VB/NER/1.txt"
#     output_path = '/home/peiwentang/Documents/Pingan/VB/NER/1.html'
#     ner.news_ana(input_path, output_path)

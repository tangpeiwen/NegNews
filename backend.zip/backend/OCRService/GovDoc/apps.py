from django.apps import AppConfig


class GovDocConfig(AppConfig):
    name = 'GovDoc'

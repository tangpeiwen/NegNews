# -*- encoding: utf-8 -*-
'''
@File    :   static_path.py
@Author :   Chi Zhang
'''
static_prefix_local = "/home/ubuntu/NegNews/predeploy/data/"
static_prefix_remote = "http://3.94.1.66:8000/vbapi/show_data/?path="

from django.shortcuts import render
import json
import threading
from django.http import HttpResponse
import requests
import os
from GovDoc import static_path


# Create your views here.
OCR_PATH = "/home/ubuntu/NegNews/FormReader_deploy_20191223"
def __ocr_extraction(request):
    if request.method != "POST":
        return HttpResponse("Bad Request!")
    print("准备启动OCR")
    ocr_paras = json.loads(request.body.decode())
    session_id = ocr_paras["session_id"]
    file_list = ocr_paras["file_list"]
    result = dict()
    for file in file_list:
        in_path = file["doc_file_location"]
        out_path = file["ocr_output_location"]
        doc_name = file["doc_name"]
        need_GPU = file["GPU"]
        pdf_files = os.listdir(in_path)
        # TODO 现在因为只有NAR1文件，所以pdf_files必须为1
        pdf_files = [file for file in pdf_files if not file.startswith(".")]
        if len(pdf_files) == 1:
            in_path = in_path + pdf_files[0]
            try:
                # 启动异步爬虫
                # t = threading.Thread(target=__start_ocr,args=(session_id,in_path,out_path,doc_name,need_GPU))
                # t.start()
                # t.join()
                t = __start_ocr(session_id,in_path,out_path,doc_name,need_GPU)
                if t=="Error":
                    return HttpResponse("ocr error")
                result[doc_name] = True
            except Exception as e:
                print(e)
                result[doc_name] = False
                return HttpResponse("ocr error")
        else:
            print("该公司NAR1文件数目不为1！异常！")
            return HttpResponse("number of NAR1 file is not one")
    return HttpResponse("Successful") #HttpResponse(json.dumps(result))


def __start_ocr(session_id=None,in_path=None,out_path=None,doc_name=None,need_GPU=None):
    print("开始执行OCR")
    os.chdir(OCR_PATH)
    os.system("python FormReader.py '"+in_path+"' '"+static_path.static_prefix_local+out_path+"' NAR1")
    print("执行OCR完毕")
    out_path = static_path.static_prefix_remote + out_path + in_path.split("/")[-1][:-4] + ".html"
    # exec OCR engine
    ocr_data = {
        "session_id":session_id,
        "doc_name":doc_name,
        "ocr_output_location":out_path,
        "ocr_status":0
    }
    # TODO only for presentation
    response = requests.post("http://inner:8001/vbservice/inner/ocrresult/",data=json.dumps(ocr_data))
    print(response)
    if response.status_code != 200:
        return "Error"

    return "Successful"

from django.urls import path

from . import views

urlpatterns = [
    path('govdococr/', views.__ocr_extraction, name='GovDoc'),
]
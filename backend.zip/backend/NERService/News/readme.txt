$ pip install -U textblob
$ python -m textblob.download_corpora # 下载nltk数据库
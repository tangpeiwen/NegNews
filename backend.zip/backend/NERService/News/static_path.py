ner_location = "contents/news_ner/"
static_prefix_local = "/home/ubuntu/NegNews/predeploy/data/"
static_prefix_remote = "/vbapi/show_data/?path="

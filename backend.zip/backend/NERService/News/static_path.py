ner_location = "contents/news_ner/"
static_prefix_local = "/root/NegNews/predeploy/data/"
static_prefix_remote = "/vbapi/show_data/?path="

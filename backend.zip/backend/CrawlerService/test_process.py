import os
from threading import Thread
import time
import requests
import json
# def count(name=None,second=None):
#     os.system("python countdown.py "+name+" "+str(second))
#     time.sleep(5)
#     print("success")
#     # countdown.countdown(name=name,second=second)
# for i in range(0,10):
#     name = "Thread-"+str(i)
#     print(name)
#     second = 15
#     t= Thread(target=count, args=(name,second),daemon=True)
#     t.start()
# # time.sleep(10)
# # t.join()
# print("finish")

content = {
    "session_id":10010000001,
    "type":1,
    "comp_cn_name":"平安",
    "comp_en_name":"Pingan",
    "shareholders":"sss"
}

response = requests.post("http://localhost:8000/crawler/negtivenews/",data=json.dumps(content))

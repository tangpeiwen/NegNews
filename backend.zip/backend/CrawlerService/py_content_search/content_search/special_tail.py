# coding=utf-8
# 不需要爬取的网页链接后缀
DOC = "doc,DOC"
DOCX = "docx,DOCX"
PDF = "pdf,PDF"
DOW = "download,DOWNLOAD"
RTF = "rtf,RTF"
MBX = "mbx,MBX"
XLS = "xls,XLS"
PPT = "ppt,PPT"
PPTX = "pptx,PPTX"
TXT = "TXT,txt"

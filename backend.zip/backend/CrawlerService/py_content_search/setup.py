from setuptools import setup, find_packages
setup(
    name = 'content_search',
    packages = ['content_search'],
    version = '0.1'
)

import json
class NegStartStatus(object):
    def __init__(self,comp_cn_name,comp_en_name,person_cn_name,person_en_name,exec_succ):
        self.comp_cn_name = comp_cn_name
        self.comp_en_name = comp_en_name
        self.person_cn_name = person_cn_name
        self.person_en_name = person_en_name
        self.exec_succ = exec_succ
    def to_string(self):
        return {"comp_cn_name":self.comp_cn_name,"comp_en_name":self.comp_en_name,"person_cn_name":self.person_cn_name,
                "person_en_name":self.person_en_name,"exec_succ":self.exec_succ}

class Person():
    def __init__(self,en_name,cn_name):
        self.en_name = en_name
        self.cn_name = cn_name

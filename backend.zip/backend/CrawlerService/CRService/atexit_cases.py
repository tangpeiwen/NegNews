import  os
from atexit import register

def main():
    while True:
        pass
@register
def _atexit():
    print('Done.')
if __name__ == '__main__':
    main()
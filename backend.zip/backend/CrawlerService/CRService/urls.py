from django.urls import path

from . import views

urlpatterns = [
    path('checkcomp/', views.checkCompExist, name='checkComp'),
    path("buyanddownload/",views.buyAndDownload, name="buyAndDownload"),
    path("negtivenews/",views.negativeNews, name="negtiveNews"),
    # path("countdown/",views.countdown,name="countdown")
]
from django.shortcuts import render
import os
from django.http import HttpResponse
import threading
import time
import requests
import json
from CRService.API3 import entities
from logging.handlers import RotatingFileHandler
import shutil
import datetime
import logging
from google_search import nagetive_search
from CRService import static_path
from content_search import crawl_content
from multiprocessing import Process, Manager
import atexit
import signal
import sys
import shutil
import json
CHECK_COMP_TEMP_FILE = "/home/ubuntu/NegNews/predeploy/data/contents/tempfile/check_comp_exist/"
ONLINE_TEMP_FILE = "/home/ubuntu/NegNews/predeploy/data/contents/tempfile/onlineView/"
BUY_TEMP_FILE = "/home/ubuntu/NegNews/predeploy/data/contents/tempfile/buy/"
DOWNLOAD_TEMP_FILE = "/home/ubuntu/NegNews/predeploy/data/contents/tempfile/download/"
CR_SPIDER_PATH = "/home/ubuntu/NegNews/crawler/crweb"

# Create your views here.
RETRY = 1

BUYSUCC = 200
DOWNLOADSUCC = 200

processes = []
def checkCompExist(request):
    if request.method != "POST":
        return HttpResponse("Bad Request!")

    print("查询公司")
    comp_info = json.loads(request.body.decode())
    comp_num = comp_info["cr_num"]
    #执行爬虫
    os.chdir(CR_SPIDER_PATH)
    os.system('scrapy crawl company_check -a compNum=\"' + comp_num + '\"')
    #检查日志
    try:
        f = open(CHECK_COMP_TEMP_FILE+comp_num,'r')
        return HttpResponse(json.dumps(eval(f.read())))
    except:
        return HttpResponse(json.dumps({"exec_succ": False}))

def buyAndDownload(request):
    if request.method != "POST":
        return HttpResponse("Bad Request!")

    print("启动购买和下载政府文件流程")
    comp_info = json.loads(request.body.decode())
    comp_name_en = comp_info["comp_en_name"]
    comp_name_cn = comp_info["comp_cn_name"]
    sessionId = comp_info["session_id"]
    cr_num = comp_info["cr_num"]
    #TODO:这里的取名字取错了english name中
    print("comp_name_en:"+comp_name_en)
    # 如果启动三次都失败，返回失败

    try:
        # 启动异步爬虫
        print("1. 启动政府文件购买流程")
        # t = threading.Thread(target=__start_gov_crawler,args=(comp_name_en,sessionId,cr_num))
        # t.start()
        # t.join()
        result =__start_gov_crawler(comp_name_en,sessionId,cr_num)
        print ('启动政府文件购买流程结果: '+ str(result))
        return HttpResponse(json.dumps(result))
    except Exception as e:
        print(e)
    # 如果启动三次都失败，返回失败
    result = {"exec_succ":False, "exec_status":"crawler error"}
    return HttpResponse(json.dumps(result))

def negativeNews(request):
    if request.method == "POST":
        print("启动负面新闻爬取")
        request_info = json.loads(request.body.decode())
        session_id = request_info["session_id"]
        type = request_info["type"]
        search_type = request_info["search_type"]
        shareholders = request_info["shareholders"]
        comp_cn_name = request_info["comp_cn_name"]
        comp_en_name = request_info["comp_en_name"]
        # crawl neg news for each shareholder
        neg_start_statuses = []
        neg_start_status = None
        if shareholders != '':
        # company
            if type == 1:
                # cn
                if comp_cn_name != "":
                    neg_start_status = __gen_neg_status(type=type,comp_cn_name=comp_cn_name,comp_en_name="",person_cn_name=""
                                                        ,person_en_name="",lang="cn",session_id=session_id,
                                                        search_type=search_type)
                    neg_start_statuses.append(neg_start_status.to_string())
                # en
                if comp_en_name != "":
                    neg_start_status = __gen_neg_status(type=type,comp_cn_name="",comp_en_name=comp_en_name,person_cn_name=""
                                                        ,person_en_name="",lang="en",session_id=session_id,
                                                        search_type=search_type)
                    neg_start_statuses.append(neg_start_status.to_string())
            # shareholders
            elif type == 0:
                for shareholder in shareholders:
                    person = entities.Person(shareholder["en_name"],shareholder["cn_name"])
                    if person.cn_name != "" and comp_cn_name != "":
                        neg_start_status = __gen_neg_status(type=type, comp_cn_name=comp_cn_name, comp_en_name="",
                                                            person_cn_name=person.cn_name, person_en_name="", lang="cn",session_id=session_id,
                                                            search_type=search_type)
                        neg_start_statuses.append(neg_start_status.to_string())
                    if person.en_name != "" and comp_en_name != "":
                        neg_start_status = __gen_neg_status(type=type, comp_cn_name="", comp_en_name=comp_en_name,
                                                            person_cn_name="", person_en_name=person.en_name, lang="en",session_id=session_id,
                                                            search_type=search_type)
                        neg_start_statuses.append(neg_start_status.to_string())
            elif type == 2:
                for shareholder in shareholders:
                    person = entities.Person(shareholder["en_name"],shareholder["cn_name"])
                    if person.cn_name != "":
                        neg_start_status = __gen_neg_status(type=type, comp_cn_name=None, comp_en_name=None,
                                                            person_cn_name=person.cn_name, person_en_name="", lang="cn",session_id=session_id,
                                                            search_type=search_type)
                        neg_start_statuses.append(neg_start_status.to_string())
                    if person.en_name != "":
                        neg_start_status = __gen_neg_status(type=type, comp_cn_name=None, comp_en_name=None,
                                                            person_cn_name="", person_en_name=person.en_name, lang="en",session_id=session_id,
                                                            search_type=search_type)
                        neg_start_statuses.append(neg_start_status.to_string())
            return HttpResponse(json.dumps({"neg_start_status":neg_start_statuses}))
        else:
            return HttpResponse('Input error')
    else:
        return HttpResponse("Bad Request!")

def __start_gov_crawler(compname=None, sessionId=None, cr_num=None):
    succ = False
    orderno = ""
    result = ""
    online_view_path = ""
    os.chdir(CR_SPIDER_PATH)
    # TODO 先判定是否有该购买结果，如果有就不爬了
    # 爬虫会保存一个文件，记录爬取是否成功，以及orderno
    os.system('scrapy crawl cr_page_info_spider -a cr_num=\"' + cr_num + '\" -a comp_name_en=\"'+compname+'\"')
    try:
        online_f = open(ONLINE_TEMP_FILE+cr_num,"r")
        #print (online_f.read())
        #s = online_f.read()
        #json_acceptable_string = s.replace("'", "\"")
        #result = json.loads(json_acceptable_string)
        result = eval(online_f.read())
        print('读取文件result: '+ str(result))
        online_f.close()
    except:
        return {"exec_succ":False, "exec_status":"online view failed"}

    if result['content']['reason'] == "Buy Successfully.":
        online_view_path = result['content']['download_path']
    else:
        return {"exec_succ":False, "exec_status":result['content']['reason']}
    time.sleep(10)
    os.system('scrapy crawl company_registry -a compname=\"' + compname + '\" -a crnumber=\"'+cr_num+'\"')
    # 读取文件，检查是否成功
    try:
        buy_f = open(BUY_TEMP_FILE + compname, 'r')
        result = eval(buy_f.read())
        buy_f.close()
    except:
        return {"exec_succ":False, "exec_status":"buy failed"}

    if result["code"] == BUYSUCC:
        print("1.1 购买成bu功")
        orderno = result["content"]["orderId"]
        # 如果成功，进行文件下载
        print("wait for download...")
        for i in range(0,300):
            time.sleep(1)
        # 爬虫会保存一个文件，记录下载是否成功，以及文件存储路径
        print("2. 启动政府文件下载流程")
        os.system('scrapy crawl company_registry_downloader -a compname=\"' + compname + '\" -a orderno=\"' + orderno + '\"')
        # 读取文件，获取内容
        try:
            download_f = open(DOWNLOAD_TEMP_FILE + orderno, 'r')
            result = json.loads(download_f.read())
            print(result)
            download_f.close()
        except:
            return {"exec_succ":False, "exec_status":"download failed"}

        if isinstance(result["result"],list):
            finish_crawl = {'session_id':sessionId,'result_list':result["result"],'online_view_path':online_view_path}
            print(finish_crawl)
            # TODO delete
            inner_result = requests.post("http://inner:8001/vbservice/inner/crdownloadresult/",data=json.dumps(finish_crawl))
            if inner_result.status_code != 200:
                return {"exec_succ": False, "exec_status":"inner service error"}
            elif inner_result.text != "Successful":
                return {"exec_succ": False, "exec_status":inner_result.text}
            return {"exec_succ": True}
        else:
            print("下载公司文件失败，公司为:"+compname+",orderid是:"+str(orderno))
            return {"exec_succ":False, "exec_status":"download failed"}
    elif result["code"] == 408:
        return {"exec_succ":False, "exec_status":result['content']['reason']}
    else:
        print("购买公司文件失败,公司为:"+compname)
        return {"exec_succ":False, "exec_status":"buy failed"}

def __gen_neg_status(type=None,comp_cn_name=None,comp_en_name=None,person_cn_name=None,person_en_name=None,lang=None,session_id=None,search_type=None):
    print('current pid is %s' % os.getpid())

    manager = Manager()
    return_dict = manager.dict()

    if lang == "cn":
        cn_t = Process(target=__start_neg_crawler, args=(type, comp_cn_name, person_cn_name, lang, session_id, search_type, return_dict))
        cn_t.start()
        en_t.join()
        # __start_neg_crawler(type, comp_cn_name, person_cn_name, lang, session_id)
    elif lang == "en":
        en_t = Process(target=__start_neg_crawler, args=(type, comp_en_name, person_en_name, lang, session_id, search_type, return_dict))
        en_t.start()
        en_t.join()
        # __start_neg_crawler(type, comp_en_name, person_en_name, lang, session_id)

    neg_start_status = entities.NegStartStatus(comp_cn_name, comp_en_name, person_cn_name, person_en_name, return_dict["status"])

    return neg_start_status

# TODO Analyse Crawler Result and Call InAPI3
def __start_neg_crawler(type=None,comp_name=None,person_name=None,lang=None,session_id=None, search_type=None, return_dict=None):
    print("comp_name", comp_name, "person_name", person_name, "search_type", search_type)
    print("current sub-process pid:%s" % os.getpid())

    keyword = static_path.keyword
    if search_type =="person":
        keyword =static_path.p_keywords
    elif search_type =="company":
        keyword =static_path.c_keywords

    today_news_db_folder = static_path.news_db + str(datetime.date.today())
    today_news_content_folder = static_path.news_content + str(datetime.date.today())
    if not os.path.exists(today_news_db_folder):
        os.mkdir(today_news_db_folder)
    if not os.path.exists(today_news_content_folder):
        os.mkdir(today_news_content_folder)
    detail_list = []
    # retail
    if comp_name == None and person_name != None:
        comp_name = ""
        news_db = today_news_db_folder + "/" + person_name+".db"
        news_content = today_news_content_folder + "/" + person_name
        # 如果文件夹已经存在，删除再创建,这个样可以让每个公司进行多次查询bug24
        if not os.path.exists(news_content):
            os.mkdir(news_content)
        else:
            shutil.rmtree(news_content, ignore_errors=True)
            os.mkdir(news_content)
        # TODO 这部分一处操作适用于kill，需要融入到google_api
        # def cleanup(num, frame):
        #     print("Terminated %s" % os.getpid())
        #     os.removedirs(news_content)
        #     print("Done!")
        #     sys.exit()
        # signal.signal(signal.SIGTERM, cleanup)
        logger = _log_conf(person_name+".log")
        search = nagetive_search.search(logger=logger)
        crawler = crawl_content.HTMLContentRetrival(logger=logger)
        search.meta_data_import(function="retail", keyword_f=keyword, personname=person_name)
        link_result = search.crawl_googleapi(function="retail", fileStorage=news_db)
        print(link_result)
        if link_result["result"] == "succ":
            detail_list = crawler.start_retrival(db_path=news_db, file_folder=news_content, excluded_path=static_path.excluded_web, lang=lang)
    # comp+person
    elif comp_name != None  or person_name != None:
        news_db = today_news_db_folder + "/" + comp_name +"_"+ person_name+".db"
        news_content = today_news_content_folder + "/" + comp_name +"_"+ person_name
        logger = _log_conf(comp_name +"_"+ person_name+".log")
        search = nagetive_search.search(logger=logger)
        crawler = crawl_content.HTMLContentRetrival(logger=logger)
        search.meta_data_import(function="single_person", keyword_f=keyword, compname=comp_name, personname=person_name)
        link_result = search.crawl_googleapi(function="single_person", fileStorage=news_db)
        if link_result["result"] == "succ":
            detail_list = crawler.start_retrival(db_path=news_db, file_folder=news_content, excluded_path=static_path.excluded_web, lang=lang)
    # comp
    elif comp_name != None  or person_name == None:
        news_db = today_news_db_folder + "/" + comp_name + ".db"
        news_content = today_news_content_folder + "/" + comp_name
        logger = _log_conf(comp_name + ".log")
        search = nagetive_search.search(logger=logger)
        crawler = crawl_content.HTMLContentRetrival(logger=logger)
        search.meta_data_import(function="single_comp", keyword_f=keyword, compname=comp_name)
        link_result = search.crawl_googleapi(function="single_comp", fileStorage=news_db)
        if link_result["result"] == "succ":
            detail_list = crawler.start_retrival(db_path=news_db, file_folder=news_content, excluded_path=static_path.excluded_web, lang=lang)

    response_data = {"session_id": session_id, "type": type, "person_name": person_name, "comp_name": comp_name,
                     "return_code": 200,
                     "detail_list": detail_list}
    response = requests.post("http://inner:8001/vbservice/inner/negresult/",json.dumps(response_data))
    print(response)
    if response.status_code != 200 or response.text == "NER ERROR":
        return_dict["status"] = False
    else:
        return_dict["status"] = True



def _log_conf(filename):
    logging.basicConfig(
        level=logging.INFO, format='%(asctime)s:%(name)s:%(levelname)s:%(funcName)s:%(lineno)d:%(message)s',
        filename=filename, filemode='a'
    )
    logger = logging.getLogger('news_crawler')
    # links_handler = RotatingFileHandler(filename=filename, maxBytes=1024 * 1024 * 3, backupCount=5)
    # apps_formatter = logging.Formatter('%(asctime)s:%(name)s:%(levelname)s:%(funcName)s:%(lineno)d:%(message)s')
    # links_handler.setFormatter(apps_formatter)
    # logger.addHandler(links_handler)
    # logger.disabled = False
    return logger

from setuptools import find_packages,setup
setup(
    name = 'en_news_content_crawler',
    version = '0.1',
    packages = find_packages()
)

# coding=utf-8
import scrapy
import re
import os
import sqlite3
import base64
from selenium.webdriver.firefox.options import Options
from selenium import webdriver
from PIL import Image
from captcha_recognition import captcha_recognition
import time
from io import BytesIO
from lxml import html

class Check_Exist_Spider(scrapy.Spider):
    name = "company_check"

    # =================Constant==================
    SEARCH_SUCC = "Welcome to ICRIS!"
    WRONG_VERIFICATION = "Incorrect VERIFICATION CODE entered."
    SEARCH_CONC = "Sorry, concurrent access is not allowed!"
    NO_RESULT = "NO MATCHING RECORD FOUND FOR THE SEARCH INFORMATION INPUT!"
    TEMP_FILE = "/home/ubuntu/NegNews/predeploy/data/contents/tempfile/check_comp_exist/"
    # =================regular expression==================
    set_cookie_p = re.compile(r'JSESSIONID=(.*); path=/')
    set_route_p = re.compile(r'ROUTEID=\.(.*); path=/')
    cookie_p = re.compile(r'.*JSESSIONID=(.*)')
    route_p = re.compile(r'.*ROUTEID=\.(.*)')

    def __init__(self,compNum=None,*args, **kwargs):
        super(Check_Exist_Spider, self).__init__(*args, **kwargs)
        self.compNum = compNum
        options = Options()
        options.add_argument('--headless')
        self.driver = webdriver.Firefox(options=options)
        self.retry = 3
        self.login_success = False

    def start_requests(self):
        self.driver.get("https://www.icris.cr.gov.hk/normal.html")
        main_window_handle = None

        while not main_window_handle:
            main_window_handle = self.driver.current_window_handle

        #driver.save_screenshot("screenshot1.png")
        u_button = self.driver.find_element_by_xpath('''//a[@href="javascript:loginIguest(\'i\');"]''')
        u_button.click()

        signin_window_handle = None
        while not signin_window_handle:
            for handle in self.driver.window_handles:
                if handle != main_window_handle:
                    self.driver.switch_to.window(handle)
                    time.sleep(2)
                    if self.driver.current_url == "https://www.icris.cr.gov.hk/csci/login_i.jsp":
                        signin_window_handle = handle
                        break

        while not self.login_success and self.retry:
            time.sleep(2)
            # element = self.driver.find_element_by_id('CaptchaCode').screenshot_as_png # find part of the page you want image of
            # im = Image.open(BytesIO(element))
            # im.save("captcha.png")
            #
            # try:
            #     start_time = time.time()
            #     captcha = self.solver.solve_captcha(element)
            #     print("--- %s ---\n--- %s seconds ---" % (captcha,time.time() - start_time))
            # except:
            #     self.retry -= 1
            #     print("cannot identify captcha...retrying...{} try left".format(self.retry))
            #     continue
            img_base64 = self.driver.execute_script("""
            var ele = arguments[0];
            var cnv = document.createElement('canvas');
            cnv.width = ele.width; cnv.height = ele.height;
            cnv.getContext('2d').drawImage(ele, 0, 0);
            return cnv.toDataURL('image/jpeg').substring(22);
            """, self.driver.find_element_by_id('CaptchaCode'))

            captcha = captcha_recognition.predict(base64.b64decode(img_base64))

            CHKBOX_09 = self.driver.find_element_by_id("CHKBOX_09")
            self.driver.execute_script("arguments[0].click();", CHKBOX_09)
            self.driver.find_element_by_id("txt_acscode").send_keys(captcha)
            login_button = self.driver.find_element_by_xpath('''//input[@value = 'Accept, Submit & Login']''')
            self.driver.execute_script("arguments[0].click();", login_button)
            time.sleep(2)
            if self.WRONG_VERIFICATION in self.driver.find_element_by_tag_name("body").text:
                back_button = self.driver.find_element_by_xpath('''//input[@onclick="javascript:history.go(-1);"]''')
                back_button.click()
                self.retry -= 1
                print("wrong captcha...retrying...{} try left".format(self.retry))
            else:
                self.login_success = True

        if self.login_success:
            print("login success")
            time.sleep(10)
            self.cookies = self.driver.get_cookies()
            self.route = self.driver.get_cookie("ROUTEID")["value"]
            self.JSESSIONID = self.driver.get_cookie("JSESSIONID")["value"]
            self.BIGip = self.driver.get_cookie("BIGipServerUXPWEB_443")["value"]
            self.next_url = "https://www.icris.cr.gov.hk/csci/cps_criteria.do"
            print(self.cookies)
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': 'https://www.icris.cr.gov.hk/csci/cps_criteria.jsp',
                       'Cookie':'web.country=US; web.language=en; ROUTEID='+self.route+'; BIGipServerUXPWEB_443='+self.BIGip+'; JSESSIONID='+self.JSESSIONID
                       }
            search_formdata = {
                "nextAction":"search_company_name", "searchPage":"True", "DPDSInd":"true","searchMode":"BYCRNO", "radioButton":"BYCRNO",
                "CRNo":self.compNum, "mode":"EXACT NAME", "showMedium":"true", "language":"en", "page":"1"
            }
            self.driver.quit()
            yield scrapy.FormRequest(url=self.next_url,headers=headers,cookies=self.cookies,formdata=search_formdata,callback=self.parse_check)
        else:
            self.driver.quit()
            print("login failed")
            result = {"exec_succ":False,"exec_status":"login failed","exist":False,"company_num":self.compNum,"company_name":"","company_type":""}
            # if not os.path.exists(self.TEMP_FILE + self.compNum):
            f = open(self.TEMP_FILE + self.compNum, 'w')
            f.write(str(result))
            f.close()

    def parse_check(self,response):
        body_text = response.text
        print(body_text)
        if self.SEARCH_SUCC in body_text:
            if response.headers.getlist("Set-Cookie") == []:
                cookie_src = response.request.headers.getlist('Cookie')[0].decode("utf-8")
                splited_cookie_src = cookie_src.split(";")
                for i in splited_cookie_src:
                    if "JSESSIONID=" in i:
                        self.cookie = self.cookie_p.search(i).group(1)
                        print("爬取到的搜索公司信息页Cookie: " + self.cookie)
                    elif "ROUTEID" in i:
                        self.route = self.route_p.search(i).group(1)
                        print("爬取到的搜索公司信息页Route: " + self.route)
            else:
                cookie_src = response.headers.getlist("Set-Cookie")[0].decode("utf-8")
                route_src = response.headers.getlist("Set-Cookie")[1].decode("utf-8")
                self.cookie = self.set_cookie_p.search(cookie_src).group(1)
                print("爬取到的搜索公司信息页Cookie: " + self.cookie)
                self.route = self.set_route_p.search(route_src).group(1)
                print("爬取到的搜索公司信息页Route: " + self.route)

            if self.NO_RESULT in body_text:
                print("公司不存在")
                result = {"exist": False, "company_num": self.compNum, "company_name": "", "company_type": ""}
                # 输出temp file
                if not os.path.exists(self.TEMP_FILE + self.compNum):
                    f = open(self.TEMP_FILE + self.compNum, 'w')
                    f.write(str(result))
                    f.close()
            else:
                print("公司存在")
                s = html.fromstring(response.text)
                coyname = s.find_class("coyname")
                if coyname:
                    coyname = coyname[0].text.strip()
                else:
                    coyname = ""
                result = {"exist":True,"company_num":self.compNum,"company_name":coyname,"company_type":""}
                #输出temp file
                # if not os.path.exists(self.TEMP_FILE + self.compNum):
                f = open(self.TEMP_FILE+self.compNum,'w')
                f.write(str(result))
                f.close()

            self.next_url = "https://www.icris.cr.gov.hk/csci/logout_s.do"
            headers = {'Host': 'www.icris.cr.gov.hk',
                       'Origin': 'https://www.icris.cr.gov.hk',
                       'Referer': self.next_url,
                       'Cookie':'web.country=US; web.language=en; ROUTEID='+self.route+'; BIGipServerUXPWEB_443='+self.BIGip+'; JSESSIONID='+self.JSESSIONID
                       }
            yield scrapy.Request(url=self.next_url, headers=headers, callback=self.parse_logout)

        elif self.SEARCH_CONC in body_text:
            print("ERROR:重复登录被网站拒绝")
            result = {"exec_succ":False,"exec_status":"concurrent login","exist":False,"company_num":self.compNum,"company_name":"","company_type":""}
            # if not os.path.exists(self.TEMP_FILE + self.compNum):
            f = open(self.TEMP_FILE + self.compNum, 'w')
            f.write(str(result))
            f.close()
        else:
            print("ERROR:自动登录失败，请检查请求体")
            result = {"exec_succ":False,"exec_status":"crawl error, cannot check company existence","exist":False,"company_num":self.compNum,"company_name":"","company_type":""}
            # if not os.path.exists(self.TEMP_FILE + self.compNum):
            f = open(self.TEMP_FILE + self.compNum, 'w')
            f.write(str(result))
            f.close()

    def parse_logout(self,response):
        body_text = response.text
        if self.SEARCH_SUCC in body_text:
            # self.update_icris_account()
            print("登出成功，爬虫即将结束程序。")
        else:
            # 登出失败，账号不要变更状态，否则会出现其他使用者无法正常使用该账号状态。
            print("登出失败，需要人工通过postman登出网站.公司名称:"+self.comp_name_en)

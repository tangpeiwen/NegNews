from Cython.Distutils import build_ext
from distutils.core import Extension, setup

ext_modules = [
    Extension("start_buy_process", ["start_buy_process.py"]),
    Extension("start_download_process", ["start_download_process.py"]),
    # Extension("cr_pageinfo_spider", ["cr_pageinfo_spider.py"]),
    # Extension("view", ["view.py"])
    # Extension("download_spider", ["download_spider.py"]),
    # Extension("captcha_test", ["captcha_test.py"]),
]

for e in ext_modules:
    e.cython_directives = {"language_level": "3"}

setup(
    name="crawler",
    version="0.1.0a0",
    description="Pins Capital",
    cmdclass={"build_ext": build_ext},
    ext_modules=ext_modules,
)
import sys
import time

def countdown(name=None,second=None):
    second = int(second)
    while second>0:
        with open(name+".log",'a') as f:
            f.write('T-minus'+str(second))
        second -=1
        time.sleep(5)

if __name__=="__main__":
    name = sys.argv[1]
    second = sys.argv[2]
    # print("name",name,"second",second)
    countdown(name=name,second=second)
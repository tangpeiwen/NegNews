# -*- coding: utf-8 -*-
from django.http import HttpResponse
from ..models import OverallProcessCompany, GovDoc, Company
import json
import requests
from VBService.views import static_path
SUCC = 200



# Inner API1
def receive_cr_result(request):
    if request.method != "POST":
        return HttpResponse("Bad Request!")
    print("接收到CR文件爬取结果")
    crawl_result = json.loads(request.body.decode())
    cr_list = crawl_result["result_list"]
    session_id = crawl_result["session_id"]
    online_view_path = crawl_result["online_view_path"]
    print(session_id)
    op = OverallProcessCompany.objects.get(session_id=session_id)
    comp = Company.objects.get(overall_process=op)
    file_list = []
    print("cr_list",cr_list)
    for cr in cr_list:
        crawl_type = cr["type"]
        return_code = cr["return_code"]
        doc_loc = cr["doc_file_location"]
        doc_out = static_path.ocr_location
        doc_name = cr["doc_name"]
        if crawl_type == "download" and return_code == SUCC and "nar1" in doc_name.lower():
            doc_record = GovDoc(doc_name=doc_name, doc_file_location=doc_loc, overall_process=op)
            doc_record.save()
            #　output and source are in the same directory
            file = {"doc_file_location":doc_loc,"ocr_output_location":doc_out,"doc_name":doc_name,"GPU":0}
            file_list.append(file)
            # output ocr status in logging
            break
    remote_online_view_path = static_path.static_prefix_remote+"contents/gov/"+comp.en_name+"/icris_online.html"
    online_doc_record = GovDoc(doc_name="online_view",doc_file_location=online_view_path, ocr_output_location=remote_online_view_path,overall_process=op)
    online_doc_record.save()
    op.gov_crawled_status = True
    print(file_list)
    # 对于没有文档的公司
    if file_list == []:
        op.gov_ocr_status = True
        op.status = "Successful"
        op.save()
        return HttpResponse("Successful")
    op.save()
    # TODO start OCR
    result = {"session_id": session_id, "file_list": file_list}
    response = requests.post("http://ocr:8003/ocr/govdococr/", data=json.dumps(result))
    print(response)

    if response.status_code != 200:
        return HttpResponse("OCR error")
    elif response.text != "Successful":
        return HttpResponse(response.text)

    return HttpResponse("Successful")

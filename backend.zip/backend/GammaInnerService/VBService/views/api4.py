from django.http import HttpResponse
from ..models import OverallProcess
import json
import datetime
import pdfkit
from json2html import *
from VBService.views import static_path

def receive_ner_result(request):
    if request.method != 'POST':
        return HttpResponse('Bad Request')
    var = json.loads(request.body.decode())
    #print (var)
    if 'session_id' in var and 'type' in var and 'return_code' in var:
        if var['return_code'] != 200:
            return HttpResponse('Ner engine failed')
        print("接收到NER分析结果")
        session_id = var['session_id']
        detail_list = var['detail_list']
        op = OverallProcess.objects.get(session_id=session_id)
        if var['type'] == 0 or var['type'] == 2:  # person or retail
            person_name = var['person_name']
            shareholders = op.shareholders.all()
            person = None
            if all(ord(c) < 128 for c in person_name):
                for shareholder in shareholders:
                    if shareholder.en_name == person_name:
                        person = shareholder
                        break
            else:
                for shareholder in shareholders:
                    if shareholder.cn_name == person_name:
                        person = shareholder
                        break
            for result in detail_list:
                result_list = result["result_list"]
                for news in result_list:
                    if news["if_neg"]:
                        person.personal_news_links.filter(link=news['link'])\
                            .update(ner_output_location=news['ner_output_location'], news_ner_status=True)
                        person.personal_news_links.filter(link=news['link'])\
                            .update(NegPoint=news['NegPoint'], news_ner_status=True)
                        person.personal_news_links.filter(link=news['link'])\
                            .update(ParaText=news['ParaText'], news_ner_status=True)
                        person.personal_news_links.filter(link=news['link'])\
                            .update(Entity = news['Entity'],news_ner_status=True)
                    else:
                        person.personal_news_links.filter(link=news['link']) \
                            .update(news_ner_status=True)
            # TODO determine whether 'personal_ner_status' should be update here?
            person.personal_ner_status = True
            person.save()
        elif var['type'] == 1:  # company
            for result in detail_list:
                result_list = result["result_list"]
                for news in result_list:
                    op.comp_application.comp_news_links.filter(link=news['link'])\
                        .update(ner_output_location=news['ner_output_location'], news_ner_status=True)
            # TODO determine whether 'comp_ner_status' should be update here?
            op.comp_application.comp_ner_status = True
            op.comp_application.save()
        # TODO determine whether 'is_all_ner_finished' should be update here?
        op.is_all_ner_finished = True
        op.status = "Successful"
        op.save()
        compliance_check = {"session id":session_id,"start time":str(op.record_created_time)+" Hongkong Time",
                            "end time":str(datetime.datetime.now())+" Hongkong Time","news ner records":[]}
        news = op.shareholders.all()[0].personal_news_links.all()
        date = ""


        for each in news:
            news_file_location = each.news_file_location
            record = {"id":news_file_location.split("/")[-1].split(".")[0],"title":each.news_title,
                      "original link":each.link}
            date = each
            if each.ner_output_location == None:
                record["ner record"] = ""
                record["if negative"] = "False"
            else:
                record["ner record"] = each.ner_output_location
                record["if negative"] = "True"
            compliance_check["news ner records"].append(record)
        with open(static_path.full_news_path + str(datetime.date.today()) + "/" + var['person_name']+ '/compliance_check.json','w') as f:
            f.write(json.dumps(compliance_check))
        html = json2html.convert(json=compliance_check)
        try:
            pdfkit.from_string(html, static_path.full_news_path + str(datetime.date.today()) + "/" + var['person_name']
                               + '/compliance_check.pdf')
        except Exception as e:
            print(e)
        return HttpResponse('Succeed to load data')
    return HttpResponse('No enough parameters')

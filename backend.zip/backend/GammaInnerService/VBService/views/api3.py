# -*- coding: utf-8 -*-
from django.http import HttpResponse
from ..models import OverallProcess, CompNews, PersonalNews
import json
import requests
from VBService.views import static_path
import datetime


# TODO change to server location in the future
# Inner API3


def receive_neg_result(request):
    if request.method != 'POST':
        return HttpResponse('Bad Request')
    var = json.loads(request.body.decode())
    #print('neg_result:'+ str(var))

    if 'session_id' in var and 'type' in var \
            and 'comp_name' in var and 'return_code' in var:
        if var['return_code'] != 200:
            return HttpResponse('Crawling engine failed')
        print("接收到负面新闻爬取结果")
        session_id = var['session_id']
        comp_name = var['comp_name']
        detail_list = var['detail_list']
        op = OverallProcess.objects.get(session_id=session_id)
        ner_items = []
        ner_output_location = static_path.ner_location + str(datetime.date.today()) +"/"
        ner_news = dict()
        if var['type'] == 0 or var['type'] == 2:  # person or retail
            # TODO implement personal news in another way, e.g. determining a person by serializable id
            person_name = var['person_name']
            shareholders = op.shareholders.all()
            person = None
            if all(ord(c) < 128 for c in person_name):
                for shareholder in shareholders:
                    if shareholder.en_name == person_name:
                        person = shareholder
                        break
            else:
                for shareholder in shareholders:
                    if shareholder.cn_name == person_name:
                        person = shareholder
                        break
            if person is None:
                return HttpResponse("No such person")
            for result in detail_list:
                keyword = result['keyword']
                result_list = result["result_list"]
                news_list = []
                for news in result_list:
                    temp_personal_news = PersonalNews(person_name=person_name,comp_name=comp_name, keyword=keyword,
                                                      link=news['link'], news_file_location=news['news_file_location'],
                                                      news_title=news['news_title'], news_date=news['news_date'],
                                                      person=person, crawl_start_time=news['crawl_start_time'],
                                                      crawl_end_time=news['crawl_end_time'],NegPoint=0.0,ParaText="")
                    temp_personal_news.save()
                    news = {"news_file_location":news['news_file_location'],"ner_output_location":"","link":news["link"]}
                    news_list.append(news)
                ner_item = {"keyword":keyword,"news_list":news_list}
                ner_items.append(ner_item)
            # TODO determine whether 'personal_news_crawled_status' should be update here?
            person.personal_news_crawled_status = True
            person.save()
            # the ner_news will send to ner service
            ner_news = {"session_id": session_id, "type": var['type'], "person_name": person_name,
                        "comp_name": comp_name,"ner_items":ner_items}
          #  print ('ner_news:' + str(ner_news))
        elif var['type'] == 1:  # company
            for result in detail_list:
                keyword = result['keyword']
                result_list = result["result_list"]
                news_list = []
                for news in result_list:
                    temp_comp_news = CompNews(comp_name=comp_name, keyword=keyword, link=news['link'],
                                              news_file_location=news['news_file_location'],
                                              news_title=news['news_title'], news_date=news['news_date'],
                                              company=op.comp_application, crawl_start_time=news['crawl_start_time'],
                                              crawl_end_time=news['crawl_end_time'])
                    temp_comp_news.save()
                    news = {"news_file_location": news['news_file_location'],"ner_output_location":"","link":news["link"]}
                    news_list.append(news)
                ner_item = {"keyword": keyword, "news_list": news_list}
                ner_items.append(ner_item)
            # TODO determine whether 'comp_news_crawled_status' should be update here?
            op.comp_application.comp_news_crawled_status = True
            op.save()
            ner_news = {"session_id": session_id, "type": var['type'], "person_name": "",
                        "comp_name": comp_name, "ner_items": ner_items}

        response = requests.post("http://ner:8004/ner/nernegnews/",data=json.dumps(ner_news))
        print(response)
        print (response.headers)
        if response.status_code !=200:
            return HttpResponse('NER ERROR')
        return HttpResponse('Succeed to load data')

    return HttpResponse('No enough parameters')

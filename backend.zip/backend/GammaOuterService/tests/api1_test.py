# from django.test import TestCase
#
# class FunctionTest(TestCase):
#
#      def setUp(self):
#          #setup a new record to db
#          pass
#
#      def
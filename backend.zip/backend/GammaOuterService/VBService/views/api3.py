from django.http import HttpResponse
from ..models import OverallProcess, Person, ActivityLog
from ..tasks import celery_task, start_negnews_crawl
from django.utils import timezone
import json
import requests
import re

# SME = "001"
RETAIL = "001"
to_tz = timezone.get_default_timezone()
# Api 3
def get_record(request):
    log = ActivityLog()
    over = OverallProcess()
    current_user = request.user
    log.user_name = current_user
    log.api_name = 'get_record'
    log.parameters = ""
    log.request_time = timezone.now()
    log.save()
    name = str(current_user)

    ops = OverallProcess.objects.raw('SELECT * FROM VBService_overallprocess LEFT JOIN VBService_person ON VBService_overallprocess.id = VBService_person.overall_process_as_shareholder_id WHERE VBService_overallprocess.user_name = %s', [name])
    records = {'sessions':[]}
    for op in ops:
        record = {}
        record['session_id'] = op.session_id
        record['request_time'] = op.record_created_time.astimezone(to_tz).strftime("%b %d %Y - %H:%M")
        record['status'] = op.status
        record['batch'] = op.batch

        if op.en_name != '':
            record['shareholder_name'] = op.en_name
        else:
            record['shareholder_name'] = ''

        records['sessions'].append(record)
    return HttpResponse(json.dumps(records))
    # for counter in range(5):
    #     celery_task.delay(counter)
    # records = {'sessions':[{'session_id':1,"request_time":2,"status":3,"shareholder_name":4}]}
    # return HttpResponse(json.dumps(records))

'''
Input:
Json format example in HttpRequest
{
    "session_id": 100000000001,
    "shareholders_list": [
        {"user_name_en":"John Smith","user_name_cn":""},
        {"user_name_en":"Donnie Azoff","user_name_cn":""},
        {"user_name_en":"Chuck Bass","user_name_cn":""}
    ]
}
'''
from django.db import transaction

def confirm_shareholders(request):
    if request.method != 'POST':
        return HttpResponse('Bad Request: Not a POST method')

    ctx = {}
    var = json.loads(request.body)
    print (str(var))

    current_user = request.user
    log = ActivityLog()
    log.user_name = current_user
    log.api_name = 'confirm_shareholders'
    log.parameters = str(var)
    log.request_time = timezone.now()
    log.save()
    transaction.commit()

    if var['business_type'] != 'sme':
        ctx['return_code'] = '0001'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: business type should be sme"
        return HttpResponse(json.dumps(ctx))

    if 'search_type' not in var:
        ctx['return_code'] = '0001'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: search_type missing"
        return HttpResponse(json.dumps(ctx))

    if var['search_type'] not in ["person", "company"]:
        ctx['return_code'] = '0001'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: search_type should be person or company"
        return HttpResponse(json.dumps(ctx))

    if 'shareholders_list' not in var:
        ctx['return_code'] = '0002'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: missing key shareholders_list"
        return HttpResponse(json.dumps(ctx))

    if len(var['shareholders_list']) != 1:
        ctx['return_code'] = '0003'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: shareholders_list should contain only 1 name"
        return HttpResponse(json.dumps(ctx),content_type="application/json")

    shareholder_dict = var['shareholders_list'][0]

    # check if name is valid
    # TODO: name is chinese or other non_english chars
    if shareholder_dict['user_name_en'].strip() == '':
        ctx['return_code'] = '0004'
        ctx['session_id'] = -1
        ctx['status'] = "name cannot be empty"
        return HttpResponse(json.dumps(ctx))

    if not re.match("^[A-Z0-9a-z-\s]*$",shareholder_dict['user_name_en']):
        ctx['return_code'] = '0004'
        ctx['session_id'] = -1
        ctx['status'] = "Only English name is allowed"
        return HttpResponse(json.dumps(ctx))

    shareholders = list()
    new_session_id = ''

    try:
        op = OverallProcess(session_id=0, comp_exist=True, gov_crawled_status=True,
                            gov_ocr_status=True,is_shareholders_confirm=True,status="Queued")

        op.save()
        new_session_id = RETAIL+str(op.id).zfill(10)
        OverallProcess.objects.filter(id=op.id).update(session_id=new_session_id)
        OverallProcess.objects.filter(session_id=new_session_id).update(user_name=str(request.user))
        temp_shareholder = Person(en_name=shareholder_dict['user_name_en'],
                                  cn_name=shareholder_dict['user_name_cn'],
                                  overall_process_as_shareholder=op, )
        temp_shareholder.save()
        shareholders.append(
            {"en_name": shareholder_dict['user_name_en'], "cn_name": shareholder_dict['user_name_cn']})

        data = {"session_id": new_session_id, "type": 2, "shareholders": shareholders, "comp_cn_name": "",
                "comp_en_name": "", "search_type": var['search_type']}

        start_negnews_crawl.delay(data)

        ctx['return_code'] = '0000'
        ctx['session_id'] = int(new_session_id)
        ctx['status'] = "Queued"
        return HttpResponse(json.dumps(ctx))

    except Exception as e:
        print(e)
        ctx['return_code'] = '0005'
        ctx['status'] = 'Encounter Error Before Crawling'
        if new_session_id:
            ctx['session_id'] = int(new_session_id)
            OverallProcess.objects.filter(id=op.id).update(status="Error")
        else:
            ctx['session_id'] = -1

        return HttpResponse(json.dumps(ctx))

def retry_session(request):
    ctx = {}
    var = json.loads(request.body)

    if 'session_id' not in var or "name" not in var:
        ctx['return_code'] = '0002'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: missing key"
        return HttpResponse(json.dumps(ctx))

    ops = OverallProcess.objects.filter(user_name = str(request.user),session_id=var["session_id"])

    if len(ops)!=1:
        ctx['return_code'] = '0010'
        ctx['session_id'] = var["session_id"]
        ctx['status'] = "Duplicate Seesion ID"
        return HttpResponse(json.dumps(ctx))

    op = ops[0]
    op.status = "Queued"
    op.save()

    shareholders=[{"en_name": var["name"], "cn_name": ""}]

    data = {"session_id": var["session_id"], "type": 2, "shareholders": shareholders, "comp_cn_name": "",
            "comp_en_name": "", "search_type": "person"}

    start_negnews_crawl.delay(data)

    ctx['return_code'] = '0000'
    ctx['session_id'] = var["session_id"]
    ctx['status'] = "Queued"
    return HttpResponse(json.dumps(ctx))



def batch_process(request):
    ctx = {}
    batch_file=request.FILES.get('file')

    if not batch_file.name.endswith(".txt"):
        ctx['return_code'] = '0006'
        ctx['session_id'] = -1
        ctx['status'] = 'Currently Only Allow txt File Upload'
        return HttpResponse(json.dumps(ctx))

    names = batch_file.read().decode("utf-8").strip().split("\n")
    if len(names)>50:
        ctx['return_code'] = '0007'
        ctx['session_id'] = -1
        ctx['status'] = 'Currently Only Allow Maxmimum 50 Names per Batch'
        return HttpResponse(json.dumps(ctx))

    for name in names:
        input_split = name.split(',')
        if len(input_split)!=2:
            ctx['return_code'] = '0008'
            ctx['session_id'] = -1
            ctx['status'] = 'wrong input format'
            return HttpResponse(json.dumps(ctx))

        name, search_type = input_split

        if len(name)>50:
            ctx['return_code'] = '0008'
            ctx['session_id'] = -1
            ctx['status'] = 'Currently Only Allow Names Less Than 50 Characters'
            return HttpResponse(json.dumps(ctx))
        if name == "":
            ctx['return_code'] = '0009'
            ctx['session_id'] = -1
            ctx['status'] = 'Empty Line in the File'
            return HttpResponse(json.dumps(ctx))
        if not re.match("^[A-Za-z-\s]*$",name):
            ctx['return_code'] = '0004'
            ctx['session_id'] = -1
            ctx['status'] = "Only English name is allowed"
            return HttpResponse(json.dumps(ctx))
        if search_type.strip() not in ["person", "company"]:
            ctx['return_code'] = '0004'
            ctx['session_id'] = -1
            ctx['status'] = "search type should be person or company"
            return HttpResponse(json.dumps(ctx))

    session_ids = []
    for idx,name in enumerate(names):
        shareholders = list()
        new_session_id = ''

        input_split = name.split(',')
        name, search_type = input_split
        name = name.strip()
        search_type = search_type.strip()

        op = OverallProcess(session_id=0, comp_exist=True, gov_crawled_status=True,
                            gov_ocr_status=True,is_shareholders_confirm=True,status="Queued")
        op.save()
        new_session_id = RETAIL+str(op.id).zfill(10)

        if idx==0:
            batch_id = "b_{}-{}".format(int(new_session_id),int(new_session_id)+len(names)-1)

        session_ids.append(int(new_session_id))
        OverallProcess.objects.filter(id=op.id).update(session_id=new_session_id)
        OverallProcess.objects.filter(id=op.id).update(batch=batch_id)
        OverallProcess.objects.filter(session_id=new_session_id).update(user_name=str(request.user))
        temp_shareholder = Person(en_name=name,
                                  cn_name="",
                                  overall_process_as_shareholder=op, )
        temp_shareholder.save()

        shareholders.append(
            {"en_name": name, "cn_name": ""})

        data = {"session_id": new_session_id, "type": 2,'search_type': search_type, "shareholders": shareholders, "comp_cn_name": "",
                "comp_en_name": ""}

        start_negnews_crawl.delay(data)

    ctx['return_code'] = '0000'
    if len(session_ids)==1:
        ctx['session_id'] = session_ids[0]
    else:
        ctx['session_id'] = "{}-{}".format(session_ids[0],session_ids[-1])
    ctx['status'] = 'batch upload successful'
    return HttpResponse(json.dumps(ctx))

def test_function(request):
    var = json.loads(request.body.decode())
    print('success')
    ctx = {}
    ctx['return_code'] = '0000'
    ctx['session_id'] = var['session_id']
    return HttpResponse(json.dumps(ctx))

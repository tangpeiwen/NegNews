from django.http import HttpResponse
from VBService.views import static_path
import json
import re
import requests
import csv
from ..models import ActivityLog
from django.utils import timezone

def set_paras(request):
    var = json.loads(request.body)

    current_user = request.user
    log = ActivityLog()
    log.user_name = current_user
    log.api_name = 'set_paras'
    log.parameters = str(var)
    log.request_time = timezone.now()
    log.save()

    if not var["threshold"]:
        return HttpResponse(json.dumps({"status":"threshold can't be empty"}))
    elif not re.match("^-0.\d+$|^0$|^-1$",var["threshold"]):
        return HttpResponse(json.dumps({"status":"please enter threshold between -1 and 0"}))

    if not var["retry_countdown"]:
        return HttpResponse(json.dumps({"status":"retry time interval can't be empty"}))
    elif not var["retry_countdown"].isnumeric():
        return HttpResponse(json.dumps({"status":"please enter value between 0 and 60 for retry time interval"}))

    var["threshold"] = float(var["threshold"])
    var["retry_countdown"] = int(var["retry_countdown"])
    with open(static_path.threshold,"w") as f:
        json.dump(var,f)

    if var["p_keywords"]:
        with open(static_path.p_keywords, 'w', newline='') as csvfile:
            spamwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
            for keyword in var["p_keywords"]:
                spamwriter.writerow([keyword])

    if var["c_keywords"]:
        with open(static_path.c_keywords, 'w', newline='') as csvfile:
            spamwriter = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
            for keyword in var["c_keywords"]:
                spamwriter.writerow([keyword])

    return HttpResponse(json.dumps({"status":"new parameters are saved"}))

def get_paras(request):
    with open(static_path.threshold) as f:
        params = json.load(f)

    return HttpResponse(json.dumps(params))

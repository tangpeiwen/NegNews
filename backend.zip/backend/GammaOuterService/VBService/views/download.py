# -*- encoding: utf-8 -*-
from django.http import FileResponse,HttpResponse,StreamingHttpResponse
from django.shortcuts import render
from ..models import OverallProcessCompany, OverallProcess,GovDoc,Company,Person,PersonalNews,ActivityLog
from wsgiref.util import FileWrapper
import os,tempfile
from VBService.views import static_path
import traceback
import re
import os
import datetime
import pdfkit
from json2html import *
from io import StringIO
import urllib
import zipfile
import shutil
import csv
from django.utils import timezone
from ..models import ActivityLog
import json
import urllib
import os.path

PDF_loc = "/home/ubuntu/NegNews/predeploy/data/contents/gov/"

def download(request):
    #var = json.loads(request.body)
    #current_user = request.user
    #log = ActivityLog()
    #log.user_name = current_user
    #log.api_name = 'download'
    #log.parameters = str(var)
    #log.request_time = timezone.now()
    #log.save()
    if request.method == "GET":
        #var = json.dumps(request.GET)
        session_id = request.GET.get("session_id")
        type = request.GET.get("type")
        news_ids = request.GET.getlist('news_ids[]')
        var = {'session_id':session_id,'type':type,'news_ids':str(news_ids)}
        current_user = request.user
        log = ActivityLog()
        log.user_name = current_user
        log.api_name = 'download'
        log.parameters = str(var)
        log.request_time = timezone.now()
        log.save()
        #session_id = request.GET.get("session_id")
        #type = request.GET.get("type")
        #news_ids = request.GET.getlist('news_ids[]')
        if type == "ocr":
            try:
                op = OverallProcessCompany.objects.get(session_id=session_id)
                if op:
                    docs = GovDoc.objects.filter(overall_process=op)
                    comps = Company.objects.filter(overall_process=op)
                    #只有icris online
                    if docs.exists() and len(docs) == 1 and docs[0].doc_name=="online_view":
                        print("only has icris")
                        comp = comps[0]
                        cwd = os.getcwd()
                        os.chdir(PDF_loc+comp.en_name)
                        # generate compliance file for comp without NAR1
                        doc = docs[0]
                        compliance_check = {"session id": session_id, "start time": str(op.record_created_time)+" Hongkong Time",
                                            "end time": str(doc.record_created_time)+" Hongkong Time", "icris ocr file record": []}
                        compliance_check["icris ocr file record"].append(
                                {"filename": doc.doc_name, "path": doc.ocr_output_location})
                        html = json2html.convert(json=compliance_check)
                        pdfkit.from_string(html, 'compliance_check.pdf')
                        en_name = re.sub(r'[&\s;,\.()]', '_', comp.en_name)
                        zipname = comp.cr_num+"-"+en_name+".zip"
                        print("zip文件名:" + zipname)
                        print("zip -r "+zipname+" Document\ Image* icris_online.html icris_online.json compliance_check.pdf")
                        if not os.path.exists(zipname):
                            os.system("zip -r "+zipname+" Document\ Image* icris_online.html icris_online.json compliance_check.pdf")
                        response = StreamingHttpResponse(file_iterator(os.getcwd() + "/" + zipname))
                        response['Content-Type'] = 'application/zip'
                        response['Content-Disposition'] = 'attachment;filename="'+zipname+'"'
                        os.chdir(cwd)
                        return response
                    #有NAR1
                    elif docs.exists() and len(docs) > 1:
                        print("has icris and nar1")
                        doc = None
                        for doc_record in docs:
                            if "nar1" in doc_record.doc_name.lower():
                                doc = doc_record
                        comp = comps[0]
                        doc_location = doc.doc_file_location
                        ocr_location = doc.ocr_output_location
                        ocr_json_location = ""
                        if doc and doc_location:
                            cwd = os.getcwd()
                            os.chdir(doc_location)
                            os.chdir("..")
                            if ocr_location:
                                ocr_location = ocr_location.split("/")[-1]# "/".join(ocr_location.split("/")[-2:])
                                ocr_json_location = ocr_location.replace(".html",".json")
                            en_name = re.sub(r'[&\s;,\.()]', '_', comp.en_name)
                            zipname = comp.cr_num + "-" + en_name + ".zip"
                            print("zip文件名:" + zipname)
                            print("zip -r " + zipname + " Document\ Image* icris_online.html icris_online.json compliance_check.pdf " + ocr_location)
                            if not os.path.exists(zipname):
                                os.system("cp ../../gov_ocr/"+ocr_location+" .")
                                os.system("zip -r " + zipname + " Document\ Image* icris_online.html icris_online.json compliance_check.pdf " + ocr_location)
                                if ocr_json_location and os.path.exists("../../gov_ocr/" + ocr_json_location):
                                    os.system("cp ../../gov_ocr/"+ocr_json_location+" .")
                                    os.system("zip -r " + zipname + " " + ocr_json_location)
                            response = StreamingHttpResponse(file_iterator(os.getcwd() + "/" + zipname))
                            response['Content-Type'] = 'application/zip'
                            response['Content-Disposition'] = 'attachment;filename="' + zipname + '"'
                            os.chdir(cwd)
                            return response
                    #对于只有NAR没有icris online的老记录，也要支持下载
                    elif comps.exists():
                        print("old guy")
                        comp = comps[0]
                        en_name = comp.en_name
                        if os.path.exists(PDF_loc+en_name):
                            cwd = os.getcwd()
                            os.chdir(PDF_loc+en_name)
                            en_name = re.sub(r'[&\s;,\.()]', '_', comp.en_name)
                            zipname = comp.cr_num + "-" + en_name + ".zip"
                            print("zip文件名:" + zipname)
                            if not os.path.exists(zipname):
                                os.system("zip -r " + zipname + " Document\ Image*")
                            response = StreamingHttpResponse(file_iterator(os.getcwd() + "/" + zipname))
                            response['Content-Type'] = 'application/zip'
                            response['Content-Disposition'] = 'attachment;filename="' + zipname + '"'
                            os.chdir(cwd)
                            return response
                        else:
                            ctx = {}
                            ctx['return_code'] = session_id + " has no file"
                            return render(request, 'web/api2.html', ctx)
                else:
                    ctx = {}
                    ctx['return_code'] = session_id + " not exist"
                    return render(request,'web/api2.html',ctx)
            except Exception as e:
                print(traceback.print_exc())
                ctx = {}
                ctx['return_code'] = session_id + " maybe not correct, please check or contact administrator."
                return render(request, 'web/api2.html', ctx)
        elif type == "ner":
            try:
                print(session_id)
                news_ids = [int(i) for i in news_ids]
                op = OverallProcess.objects.get(session_id=session_id)
                if op:
                    person = Person.objects.get(overall_process_as_shareholder=op)
                    person_id = person.id
                    person_date = str(person.record_created_time).split(' ')[0]
                    news = PersonalNews.objects.filter(pk__in = news_ids)
                    file_download = []
                    csv_folder = ''
                    ner_result = []
                    for one in news:
                        if one.news_ner_status:
                            #num = one.id
                            title = one.news_title
                            article = one.link
                            negpoint = one.NegPoint
                            para = one.ParaText
                            news_loc = one.news_file_location
                            print (news_loc)
                            file_download.append(news_loc)
                            num = os.path.basename(news_loc).split('.')[0]
                            news_html = news_loc[:-3]+'html'
                            print (news_html)
                            #new_name = os.path.split(news_loc)[0]+'/news_id'+str(num)+'.txt'
                            #print ('new name:' + new_name)
                            #if news_loc != new_name:
                            #    os.rename(news_loc,new_name)
                             #   news.filter(id = one.id).update(news_file_location=new_name)
                            file_download.append(news_html)
                            #new_html = new_name[:-3] + 'html'
                            #if news_html != new_html:
                             #   os.rename(news_html,new_html)
                            #file_download.append(new_html)
                            file_id = '_'.join(news_loc.split('/')[-2:])
                            ner_loc = static_path.static_prefix_local + "/".join(one.ner_output_location.split("path=")[1].split('/')[1:])
                            file_download.append(ner_loc)
                            #if 'path=' in one.ner_output_location:
                             #   ner_loc = static_path.static_prefix_local +"/".join(urllib.parse.quote(one.ner_output_location.split("path=")[1]).split('/')[1:])
                            #else:
                             #   ner_loc = one.ner_output_location
                            #print (ner_loc)
                            #new_ner_name = os.path.split(ner_loc)[0]+'/ner_id'+ str(num)+'.html'
                            #print ('new ner loc:'+ new_ner_name)
                            #if ner_loc != new_ner_name:
                             #   os.rename(ner_loc,new_ner_name)
                              #  news.filter(id = one.id).update(ner_output_location=new_ner_name)
                            #file_download.append(new_ner_name)
                            entity = one.Entity
                            ner_result.append([num,title,article,negpoint,para,entity])

                        csv_folder = static_path.csv_folder + person_date + "/" + one.person_name
                        if not os.path.exists(csv_folder):
                            os.makedirs(csv_folder)
                        else:
                            shutil.rmtree(csv_folder)
                            os.makedirs(csv_folder)
                        CsvFilePath = csv_folder + '.csv'
                        file_download.append (CsvFilePath)
                    #print (str(file_download))
                        with open(CsvFilePath, 'w+', newline='', encoding='utf-8-sig') as csvfile:
                            writer = csv.writer(csvfile)
                            writer.writerow(['News id','Individual negative news abstract','Hyperlink','Score','Sensitive Paragraph','Who,When,Where'])
                            writer.writerows(ner_result)
                        csvfile.close()
                    en_name = re.sub(r'[&\s;,\.()]', '_', person.en_name)
                    zipname = session_id+"-"+en_name
                    print("zip文件名:" + zipname)

                    zip_filename = "%s.zip" % zipname
                    response = HttpResponse(content_type = 'application/zip')
                    zip_file = zipfile.ZipFile(response, 'w')
                    #print (news_ids)


                    for fpath in file_download:
                        fdir, fname = os.path.split(fpath)

                        zip_path = os.path.join('NegNews', fname)
                        zip_file.write(fpath,zip_path)
                    zip_file.close()

                        #response = StreamingHttpResponse(file_iterator(os.getcwd()+"/"+zipname))
                    response['Content-Type'] = 'application/zip'
                    #response['Content-Disposition'] = 'attachment;filename="' + zipname + '"'
                    response['Content-Disposition'] = 'attachment; filename={}'.format(zipname)
                    return response
                    # else:
                    #     ctx = {}
                    #     ctx['return_code'] = session_id + " has no file"
                    #     return render(request, 'web/api6.html', ctx)
                else:
                    ctx = {}
                    ctx['return_code'] = session_id + " not exist"
                    return render(request, 'web/api6.html', ctx)

            except Exception as e:
                print(traceback.print_exc())
                ctx = {}
                ctx['return_code'] = session_id + " maybe not correct, please check or contact administrator."
                return render(request, 'web/api6.html', ctx)

def file_iterator(file_name, chunk_size=512):
    with open(file_name, 'rb') as f:
        while True:
            c = f.read(chunk_size)
            if c:
                yield c
            else:
                break

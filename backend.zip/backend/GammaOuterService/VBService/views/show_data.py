# -*- encoding: utf-8 -*-
'''
@File    :   show_data.py    
@Author :   Chi Zhang
'''
from django.shortcuts import render
import urllib.parse

def index(request):
    if request.method == "GET":
        path = request.GET.get("path")
        path = urllib.parse.unquote(path)
        return render(request,path)

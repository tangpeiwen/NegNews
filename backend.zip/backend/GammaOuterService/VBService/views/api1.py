from django.shortcuts import render
from django.http import HttpResponse
from django.db.models import Max
from ..models import OverallProcessCompany, Company, ActivityLog
import json
import requests
import sqlite3
import traceback
from django.utils import timezone
from django.contrib.auth.decorators import login_required
from ..tasks import start_icris_crawl

SME = "001"
to_tz = timezone.get_default_timezone()
# Api 1
# TODO change def name
def get_record_company(request):
    log = ActivityLog()
    current_user = request.user
    log.user_name = current_user
    log.api_name = 'get_record_company'
    log.parameters = ""
    log.request_time = timezone.now()
    log.save()
    name = str(current_user)
    ops = OverallProcessCompany.objects.raw('SELECT * FROM VBService_overallprocesscompany LEFT JOIN VBService_company ON VBService_overallprocesscompany.id = VBService_company.overall_process_id WHERE VBService_overallprocesscompany.user_name = %s', [name])
    records = {'sessions':[]}
    for op in ops:
        record = {}
        record['session_id'] = op.session_id
        record['request_time'] = op.record_created_time.astimezone(to_tz).strftime("%b %d %Y - %H:%M")
        record['status'] = op.status
        record['batch'] = op.batch
        record['cr_num'] = op.cr_num
        record['shareholder_name'] = op.en_name

        records['sessions'].append(record)
    return HttpResponse(json.dumps(records))

def check_company_num(request):
    ctx = {}
    if 'cr_num' not in request.POST:
        ctx['return_code'] = '0001'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: missing key cr_num"
        return render(request, 'web/api1.html',ctx)

    if 'comp_name_en' not in request.POST:
        ctx['return_code'] = '0001'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: missing key comp_name_en"
        return render(request, 'web/api1.html',ctx)

    print("启动流程")
    cr_num = request.POST.get('cr_num')
    comp_name_en = request.POST.get('comp_name_en')
    comp_name_cn = ""

    if not cr_num.isnumeric():
        ctx['return_code'] = '0001'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: cr number should be numeric"
        return render(request, 'web/api1.html',ctx)

    try:
        op = OverallProcessCompany(session_id=0, comp_exist=None, gov_crawled_status=True,
                            gov_ocr_status=True, status="Queued")
        
        op.save()
        new_session_id = SME + str(op.id).zfill(10)
        op.session_id=new_session_id
        op.save()
        OverallProcessCompany.objects.filter(session_id=new_session_id).update(user_name=str(request.user))
        company = Company(cr_num=cr_num, overall_process=op, en_name=comp_name_en)
        company.save()
        data = {"session_id":new_session_id, "cr_num":cr_num, "comp_name_en":comp_name_en}
        start_icris_crawl.delay(data)

        ctx['session_id'] = str(int(new_session_id))
        ctx['return_code'] = '0000'  # Exist and crawl engine started
        ctx['status'] = "Queued"
        return render(request, 'web/api1.html', ctx)

    except Exception as e:
        print(e)
        ctx['return_code'] = '0002'
        ctx['status'] = 'Encounter Error Before Crawling'
        if new_session_id:
            ctx['session_id'] = int(new_session_id)
            op.status = "Error"
            op.save()
        else:
            ctx['session_id'] = -1

        return HttpResponse(json.dumps(ctx))

def retry_icris_session(request):
    ctx = {}
    var = json.loads(request.body)

    if 'session_id' not in var or "name" not in var or "cr_num" not in var:
        ctx['return_code'] = '0002'
        ctx['session_id'] = -1
        ctx['status'] = "Input Error: missing key"
        return HttpResponse(json.dumps(ctx))

    ops = OverallProcessCompany.objects.filter(session_id=var["session_id"])

    if len(ops)!=1:
        ctx['return_code'] = '0010'
        ctx['session_id'] = var["session_id"]
        ctx['status'] = "Duplicate Seesion ID"
        return HttpResponse(json.dumps(ctx))

    op = ops[0]
    op.status = "Queued"
    op.save()


    data = {"session_id":var["session_id"], "cr_num":var["cr_num"], "comp_name_en":var["name"]}

    start_icris_crawl.delay(data)

    ctx['return_code'] = '0000'
    ctx['session_id'] = var["session_id"]
    ctx['status'] = "Queued"
    return HttpResponse(json.dumps(ctx))

def batch_process_icris(request):
    ctx = {}
    batch_file=request.FILES.get('file')

    if not batch_file.name.endswith(".txt"):
        ctx['return_code'] = '0006'
        ctx['session_id'] = -1
        ctx['status'] = 'Currently Only Allow txt File Upload'
        return HttpResponse(json.dumps(ctx))

    lines = batch_file.read().decode("utf-8").strip().split("\n")

    if len(lines)>=5:
        ctx['return_code'] = '0007'
        ctx['session_id'] = -1
        ctx['status'] = 'Currently Only Allow Maxmimum 4 Company Names per Batch'
        return HttpResponse(json.dumps(ctx))

    cr_tuple = []
    for line in lines:
        try:
            cr_num, name = line.split("\t")
            if not cr_num.isnumeric():
                ctx['return_code'] = '0001'
                ctx['session_id'] = -1
                ctx['status'] = "Input Error: cr_num should be numeric"
                return HttpResponse(json.dumps(ctx))
            cr_tuple.append((cr_num, name))
        except:
            ctx['return_code'] = '0008'
            ctx['session_id'] = -1
            ctx['status'] = 'file format incorrect, please seperate cr number and company name by tab'
            return HttpResponse(json.dumps(ctx))


    session_ids = []
    for idx,(cr_num, name) in enumerate(cr_tuple):
        op = OverallProcessCompany(session_id=0, comp_exist=None, gov_crawled_status=True,
                            gov_ocr_status=True, status="Queued")
        op.save()
        new_session_id = SME + str(op.id).zfill(10)

        if idx==0:
            batch_id = "b_{}-{}".format(int(new_session_id),int(new_session_id)+len(cr_tuple)-1)

        op.session_id=new_session_id
        op.batch=batch_id
        op.user_name = str(request.user)
        op.save()
        company = Company(cr_num=cr_num, overall_process=op, en_name=name)
        company.save()
        data = {"session_id":new_session_id, "cr_num":cr_num, "comp_name_en":name}
        start_icris_crawl.delay(data)
        session_ids.append(int(new_session_id))

    ctx['return_code'] = '0000'
    if len(session_ids)==1:
        ctx['session_id'] = session_ids[0]
    else:
        ctx['session_id'] = "{}-{}".format(session_ids[0],session_ids[-1])
    ctx['status'] = 'batch upload successful'
    return HttpResponse(json.dumps(ctx))

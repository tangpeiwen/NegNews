from django.shortcuts import render
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth import authenticate, login, get_user_model
from django.contrib.auth.models import User
from rest_framework.decorators import api_view



@login_required
def index(request):
    context = {
        "index":"index"
    }
    return render(request,'web/index.html')

@login_required
def api1(request):
    return render(request, 'web/api1.html')

@login_required
def api2(request):
    return render(request, 'web/api2.html')

# @login_required
@api_view(['POST','GET'])
def api3(request):
    if request.user.is_authenticated():
        return render(request, 'web/api3.html')

@login_required
def api4(request):
    return render(request, 'web/api4.html')

@login_required
def api5(request):
    return render(request, 'web/api5.html')

@login_required
def api6(request):
    return render(request, 'web/api6.html')

@login_required
def setup(request):
    return render(request, 'web/setup.html')

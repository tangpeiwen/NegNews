# -*- encoding: utf-8 -*-
'''
@File    :   static_path.py
@Author :   Chi Zhang
'''
gov_db = "/home/ubuntu/NegNews/predeploy/data/db/gov/sme.db"
news_folder = "/home/ubuntu/NegNews/predeploy/data/contents/news/"
static_prefix_local = '/home/ubuntu/NegNews/predeploy/data/contents/'
csv_folder = "/home/ubuntu/NegNews/predeploy/data/contents/csv/"
threshold = "/home/ubuntu/NegNews/predeploy/data/static/params.json"
p_keywords = "/home/ubuntu/NegNews/predeploy/data/static/p_keyword.csv"
c_keywords = "/home/ubuntu/NegNews/predeploy/data/static/c_keyword.csv"

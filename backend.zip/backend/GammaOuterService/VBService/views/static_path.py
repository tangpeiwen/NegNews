# -*- encoding: utf-8 -*-
'''
@File    :   static_path.py
@Author :   Chi Zhang
'''
gov_db = "/root/NegNews/predeploy/data/db/gov/sme.db"
news_folder = "/root/NegNews/predeploy/data/contents/news/"
static_prefix_local = '/root/NegNews/predeploy/data/contents/'
csv_folder = "/root/NegNews/predeploy/data/contents/csv/"
threshold = "/root/NegNews/predeploy/data/static/params.json"
p_keywords = "/root/NegNews/predeploy/data/static/p_keyword.csv"
c_keywords = "/root/NegNews/predeploy/data/static/c_keyword.csv"

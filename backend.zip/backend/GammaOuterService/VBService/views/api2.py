from django.http import HttpResponse
from django.shortcuts import render
from ..models import OverallProcessCompany, Company
import json
import traceback
import urllib.parse


# Api 2
def get_ocr_results(request):
    ctx = {}
    if 'session_id_list' not in request.POST:
        ctx["status"] = "missing key session_id_list"
        return render(request, 'web/api2.html', ctx)

    session_id_list = request.POST.getlist('session_id_list')
    if not session_id_list:
        ctx["status"] = "session_id_list is empty"
        return render(request, 'web/api2.html', ctx)

    ctx['results_list'] = []
    session_id = session_id_list[0]

    try:
        ops = OverallProcessCompany.objects.filter(session_id=session_id)
        if len(ops)>0:  # check whether the overall process in this session_id exist
            op = ops[0]
            ctx['session_id'] = op.session_id
            # get comapny name
            cps = Company.objects.filter(overall_process=op)

            if len(cps)>0:
                cp = cps[0]
                ctx['name'] = cp.en_name
            else:
                ctx['name'] = ""

            ctx['status'] = op.status
            if op.gov_crawled_status and op.gov_ocr_status:
                # TODO retrieve gov doc record from db
                gd_list = op.gov_docs_crawling.all()
                info_retrieve_dict = {}
                info_retrieve_dict['session_id'] = op.session_id
                info_retrieve_dict['ocr_result_list'] = []
                online_view_path = ""
                for gd in gd_list:
                    ocr_result_dict = {}
                    if gd.doc_name == "online_view":
                        online_view_path = gd.ocr_output_location
                    else:
                        ocr_result_dict['ocr_status'] = gd.ocr_status
                        ocr_output_location = gd.ocr_output_location.split("path=")[0]+'path='+urllib.parse.quote(gd.ocr_output_location.split("path=")[1])
                        ocr_result_dict['ocr_output_location'] = ocr_output_location
                        ocr_result_dict['doc_name'] = gd.doc_name
                        info_retrieve_dict['ocr_result_list'].append(ocr_result_dict)
                print (online_view_path)
                ctx['results_list'].append(info_retrieve_dict)
                online_view_path_parts = online_view_path.split("path=")
                online_view_path = online_view_path_parts[0]+'path='+urllib.parse.quote(online_view_path_parts[1])
                ctx['online_view_path'] = online_view_path

        else:
            ctx["status"] = "No such session id"
    except Exception as e:
        print(traceback.print_exc())
        ctx['status'] = session_id+" maybe not correct, please check."

    # return HttpResponse(json.dumps(ctx))
    return render(request, 'web/api2.html', ctx)

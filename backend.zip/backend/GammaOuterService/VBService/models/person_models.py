from django.db import models
from .overall_process_models import OverallProcess
from django.utils import timezone
from django.db import models
from django.contrib.auth.models import User
import datetime

# class User(models.Model):
#     user = models.OneToOneField(User, on_delete=models.CASCADE)
#     account_expiry = models.DateField(default=datetime.now() + timedelta(days=365))


class Person(models.Model):
    record_created_time            = models.DateTimeField(default=timezone.now,null=True)
    en_name                        = models.CharField(default='', max_length=254)
    cn_name                        = models.CharField(max_length=254, null=True)
    personal_news_crawled_status   = models.BooleanField(default=False)
    personal_ner_status            = models.BooleanField(default=False)

    overall_process_as_applicant   = models.OneToOneField(OverallProcess,
                                                          related_name='person_application',
                                                          on_delete=models.CASCADE,
                                                          null=True)

    overall_process_as_shareholder = models.ForeignKey(OverallProcess,
                                                       related_name='shareholders',
                                                       on_delete=models.CASCADE,
                                                       null=True)

    class Meta:
        app_label = 'VBService'


class PersonalNews(models.Model):
    person_name         = models.CharField(default='', max_length=254)
    keyword             = models.CharField(default='', max_length=254)
    link                = models.URLField(default='', max_length=2047)
    comp_name           = models.CharField(default='', max_length=254)
    news_file_location  = models.CharField(default='', max_length=254)
    news_title          = models.CharField(default='', max_length=254)
    NegPoint          = models.DecimalField(max_digits=3, decimal_places=2)
    ParaText          = models.TextField(default='')
    Entity            = models.CharField(default='', max_length=254)
    record_created_time = models.DateTimeField(default=timezone.now, null=True)
    news_date           = models.CharField(default='', max_length=254)
    news_ner_status     = models.BooleanField(default=False)
    ner_output_location = models.CharField(max_length=254, null=True)
    crawl_start_time = models.CharField(default='', max_length=254)
    crawl_end_time = models.CharField(default='', max_length=254)
    comment            = models.CharField(default='', max_length=254)
    person              = models.ForeignKey(Person,
                                            related_name='personal_news_links',
                                            on_delete=models.CASCADE,
                                            null=True)
    #history = HistoricalRecords()
    class Meta:
        app_label = 'VBService'

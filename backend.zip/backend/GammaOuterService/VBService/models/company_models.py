from django.db import models
from .overall_process_models import OverallProcessCompany
from django.utils import timezone

class Company(models.Model):
    record_created_time      = models.DateTimeField(default=timezone.now,null=True)
    cr_num                   = models.CharField(default='', max_length=254)
    en_name                  = models.CharField(default='', max_length=254)
    cn_name                  = models.CharField(default='', max_length=254)
    comp_news_crawled_status = models.BooleanField(default=False)
    comp_ner_status          = models.BooleanField(default=False)
    comp_created_date        = models.CharField(default='', max_length=254)
    comp_type                = models.CharField(default='', max_length=254)
    overall_process          = models.OneToOneField(OverallProcessCompany,
                                                    related_name='comp_application',
                                                    on_delete=models.CASCADE,
                                                    null=True)

    # comp_news_links        --> class CompanyNews as a set, null=True

    class Meta:
        app_label = 'VBService'


class CompNews(models.Model):
    comp_name           = models.CharField(default='', max_length=254)
    keyword             = models.CharField(default='', max_length=254)
    link                = models.URLField(default='', max_length=2047)
    news_file_location  = models.CharField(default='', max_length=254)
    news_title          = models.CharField(default='', max_length=254)
    record_created_time = models.DateTimeField(default=timezone.now, null=True)
    news_date           = models.CharField(default='', max_length=254)
    news_ner_status     = models.BooleanField(default=False)
    ner_output_location = models.CharField(max_length=254, null=True)
    crawl_start_time = models.CharField(default='', max_length=254)
    crawl_end_time = models.CharField(default='', max_length=254)
    company             = models.ForeignKey(Company,
                                            related_name='comp_news_links',
                                            on_delete=models.CASCADE,
                                            null=True)

    class Meta:
        app_label = 'VBService'

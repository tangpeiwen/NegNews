from django.db import models
from django.utils import timezone


class OverallProcess(models.Model):
    user_name         = models.CharField(default='', max_length=254)
    session_id              = models.BigIntegerField(default=-1)
    comp_exist              = models.BooleanField(default=True)
    record_created_time     = models.DateTimeField(default=timezone.now, null=True)
    gov_crawled_status      = models.BooleanField(default=False)
    gov_ocr_status          = models.BooleanField(default=False)
    is_shareholders_confirm = models.BooleanField(default=False)
    is_all_ner_finished     = models.BooleanField(default=False)
    status                  = models.CharField(default='',max_length=254, null=True)
    batch                   = models.CharField(default='',max_length=254, null=True)

    class Meta:
        app_label = 'VBService'

class OverallProcessCompany(models.Model):
    user_name         = models.CharField(default='', max_length=254)
    session_id              = models.BigIntegerField(default=-1)
    comp_exist              = models.BooleanField(default=False, null=True)
    record_created_time     = models.DateTimeField(default=timezone.now, null=True)
    gov_crawled_status      = models.BooleanField(default=False)
    gov_ocr_status          = models.BooleanField(default=False)
    status                  = models.CharField(default='',max_length=254, null=True)
    batch                   = models.CharField(default='',max_length=254, null=True)

    class Meta:
        app_label = 'VBService'


class GovDoc(models.Model):
    doc_name            = models.CharField(default='', max_length=254)
    record_created_time = models.DateTimeField(default=timezone.now,null=True)
    doc_file_location   = models.CharField(default='', max_length=254)
    ocr_output_location = models.CharField(max_length=254, null=True)
    ocr_status          = models.IntegerField(default=0)

    overall_process     = models.ForeignKey(OverallProcessCompany,
                                            related_name='gov_docs_crawling',
                                            on_delete=models.CASCADE,
                                            null=True)

    class Meta:
        app_label = 'VBService'

class ActivityLog(models.Model):
    user_name         = models.CharField(default='', max_length=254)
    request_time = models.DateTimeField(default=timezone.now,null=True)
    parameters   = models.CharField(default='', max_length=254)
    api_name = models.CharField(max_length=254, null=True)

    overall_process     = models.ForeignKey(OverallProcess, related_name='activity_logging', on_delete=models.CASCADE,null=True)
    class Meta:
        app_label = 'VBService'

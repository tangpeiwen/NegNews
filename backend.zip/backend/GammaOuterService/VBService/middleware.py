from datetime import date, timedelta
from django.urls import reverse
from django.http import HttpResponseRedirect

class AccountExpiry:

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        current_user = request.user
        response = self.get_response(request)
        expiry_path = reverse('login')

        if current_user.is_anonymous is False:
            if current_user.staff is True:
                if request.path not in [expiry_path]:
                    expiry_date = current_user.date_joined
                    todays_date = datetime.today()

                    if todays_date - expiry_date > timedelta(days=30):
                        return HttpResponseRedirect(expiry_path)
        return response

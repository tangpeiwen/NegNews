from Cython.Distutils import build_ext
from distutils.core import Extension, setup

ext_modules = [
    Extension("tasks", ["tasks.py"]),
    # Extension("api2", ["api2.py"]),
    # Extension("api3", ["api3.py"]),
    # Extension("downlaod", ["download.py"]),
    # Extension("api4", ["api4.py"]),
    # Extension("set_paras", ["set_paras.py"]),
]

for e in ext_modules:
    e.cython_directives = {"language_level": "3"}

setup(
    name="outer",
    version="0.1.0a0",
    description="Pins Capital",
    cmdclass={"build_ext": build_ext},
    ext_modules=ext_modules,
)
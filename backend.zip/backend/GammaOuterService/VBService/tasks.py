from celery import shared_task
from celery.exceptions import SoftTimeLimitExceeded
from .models import OverallProcess, OverallProcessCompany, Company
import time
import json
import requests

@shared_task
def celery_task(counter):
    email = "hassanzadeh.sd@gmail.com"
    time.sleep(30)
    return '{} Done!'.format(counter)
    # try:
    #     assert False
    # except Exception as e:
    #     print('Try {0}/{1}'.format(celery_task.request.retries, celery_task.max_retries))
    #     celery_task.retry(exc=e,countdown=5)
    #
    # return "success"

@shared_task(soft_time_limit=900)
def start_negnews_crawl(data):
    try:
        session_id = data["session_id"]
        op = OverallProcess.objects.get(session_id=session_id)
        op.status = "In Progress"
        op.save()
        print(session_id,"start crawling")

        url = 'http://crawler:8002/crawler/negtivenews/'
        para = json.dumps(data)
        result = requests.post(url=url, data=para)
        print(result.text)
        neg_start_status = json.loads(result.text)["neg_start_status"][0]
        status = neg_start_status["exec_succ"]
        print(status)
        if not status:
            assert False
        return result.text
    except SoftTimeLimitExceeded:
        op.status = "Failed: timeout"
        op.save()
        return "Failed: timeout"
    except Exception as e:
        print('Try start_negnews_crawl {0}/{1}'.format(start_negnews_crawl.request.retries, start_negnews_crawl.max_retries))
        if start_negnews_crawl.request.retries < start_negnews_crawl.max_retries:
            op.status = "Failed: retrying"
            op.save()
        else:
            op.status = "Failed"
            op.save()
        start_negnews_crawl.retry(exc=e,countdown=10)

@shared_task(queue="icris",soft_time_limit=900)
def start_icris_crawl(data):
    try:
        session_id = data["session_id"]
        cr_num = data["cr_num"]
        comp_name_en = data["comp_name_en"]
        comp_name_cn = ""

        op = OverallProcessCompany.objects.get(session_id=session_id)
        op.status = "In Process"
        op.save()
        # TODO
        # check if company has been crawled previously

        # check if company exists, if exists, get chinese and english name
        comp_exist = __request_crawler(function='check_comp_exist',para={'cr_num': cr_num},switch=False)  # = start CR online check
        print(comp_exist)
        #comp_exist = {'exist': True, 'company_num': '2032577', 'company_name': '', 'company_type': ''}

        if not comp_exist.get("exec_succ",True):
            op.status = "Failed: "+comp_exist.get("exec_status","crawler error, cannnot check company existence")
            op.save()
            return "Failed: "+comp_exist.get("exec_status","crawler error, cannnot check company existence")
        elif not comp_exist['exist']:
            op.comp_exist=False
            op.status = "Failed: cr number does not exist"
            op.save()
            return "Failed: cr number does not exist"
        else:
            op.comp_exist=True
            op.save()

        if comp_exist["company_name"]:
            comp_name_en = comp_exist["company_name"]

        cps = Company.objects.filter(overall_process=op)
        if len(cps)>0:
            company = cps[0]
            company.en_name = comp_name_en
            company.save()
        else:
            company = Company(cr_num=cr_num, overall_process=op, en_name=comp_name_en)
            company.save()


        # start crawl engine to crawl gov documents
        crawl_gov_result = __request_crawler(function='gov',
                                             para={'comp_cn_name': comp_name_cn,
                                             'comp_en_name': comp_name_en,
                                             'cr_num':cr_num,
                                             'session_id': session_id})

        assert crawl_gov_result["exec_succ"]

        if not crawl_gov_result["exec_succ"]:
            op.status = "Failed: "+ crawl_gov_result.get("exec_status","")
            op.save()
            return "Failed: "+ crawl_gov_result.get("exec_status","")

        return "Successful"
    except SoftTimeLimitExceeded:
        op.status = "Failed: timeout"
        op.save()
        return "Failed: timeout"
    except Exception as e:
        print('Try start_icris_crawl {0}/{1}'.format(start_icris_crawl.request.retries, start_icris_crawl.max_retries))
        if start_icris_crawl.request.retries < start_icris_crawl.max_retries:
            op.status = "Failed: retrying"
            op.save()
        else:
            op.status = "Failed"
            op.save()
        start_icris_crawl.retry(exc=e,countdown=600)


def __request_crawler(function=None, para=None, switch=False):
    # 检查公司存在之后需要返回公司中英文名
    if function == 'check_comp_exist':
        print("查找公司")
        url = 'http://crawler:8002/crawler/checkcomp/'
    elif function == 'gov':
        print("请求购买和下载")
        url = 'http://crawler:8002/crawler/buyanddownload/'
    elif function == 'neg':
        url = 'http://crawler:8002/crawler/negtivenews/'

    para = json.dumps(para)
    result = requests.post(url=url, data=para)
    print(result.text)
    result = json.loads(result.text)
    return result
